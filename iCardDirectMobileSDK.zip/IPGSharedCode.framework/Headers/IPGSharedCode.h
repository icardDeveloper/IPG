#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class IPGSCKotlinEnum, IPGSCCurrencyEnum, IPGSCKtor_client_coreHttpClient, IPGSCCardPresenter, IPGSCIcard, IPGSCPurchasePresenter, IPGSCRefundPresenter, IPGSCTransactionStatusPresenter, IPGSCBaseRequestModel, IPGSCBaseResponseModel, IPGSCKotlinx_serialization_runtimeJson, IPGSCBaseApi, IPGSCIPGCheckCardModel, IPGSCCheckCardModel, IPGSCIPGLogModel, IPGSCLogResponseModel, IPGSCIPGPurchaseModel, IPGSCTransactionRefModel, IPGSCIPGRefundModel, IPGSCRefundTransactionModel, IPGSCIPGStoreCardModel, IPGSCStoredCardModel, IPGSCIPGGetMerchantTax, IPGSCTaxModel, IPGSCIPGTransactionStatusModel, IPGSCTransactionStatusModel, IPGSCIPGStoredCardUpdate, IPGSCRuntimeTransacterTransaction, IPGSCLogsEntityImpl, IPGSCRuntimeQuery, IPGSCPresenterCoroutineScope, IPGSCKotlinThrowable, IPGSCBasePresenter, IPGSCStoreCardUseCase, IPGSCStoredCardUpdateUseCase, IPGSCCheckCardUseCase, IPGSCPurchaseUseCase, IPGSCGetMerchantTaxUseCase, IPGSCRefundUseCase, IPGSCGetTransactionStatusUseCase, IPGSCBaseUseCase, IPGSCCheckCardApi, IPGSCTaxApi, IPGSCTransactionStatusApi, IPGSCLogApi, IPGSCPurchaseApi, IPGSCRefundApi, IPGSCStoreCardApi, IPGSCUpdateCardApi, IPGSCAcqSchemeEnum, IPGSCEither, IPGSCEitherError, IPGSCKotlinNothing, IPGSCEitherFailure, IPGSCEitherSuccess, IPGSCBaseRequestParameters, IPGSCCartItemModel, IPGSCDatabaseDriverFactory, IPGSCKodein_diDIModule, IPGSCKtor_client_coreHttpClientConfig, IPGSCKotlinx_coroutines_coreCoroutineDispatcher, IPGSCKtor_client_coreHttpClientEngineConfig, IPGSCKtor_client_coreHttpReceivePipeline, IPGSCKtor_client_coreHttpRequestPipeline, IPGSCKtor_client_coreHttpResponsePipeline, IPGSCKtor_client_coreHttpSendPipeline, IPGSCKodein_diDITrigger, IPGSCKotlinx_serialization_runtimeJsonBuilder, IPGSCKotlinx_serialization_runtimeJsonConfiguration, IPGSCKotlinx_serialization_runtimeJsonElement, IPGSCKotlinArray, IPGSCKotlinByteArray, IPGSCKtor_utilsAttributeKey, IPGSCKotlinAbstractCoroutineContextElement, IPGSCKtor_client_coreProxyConfig, IPGSCKtor_utilsPipelinePhase, IPGSCKtor_utilsPipeline, IPGSCKodein_diDIKey, IPGSCKodein_typeTypeToken, IPGSCKotlinx_serialization_runtimeUpdateMode, IPGSCKotlinx_serialization_runtimeJsonNull, IPGSCKotlinx_serialization_runtimeJsonPrimitive, IPGSCKotlinx_serialization_runtimeSerialKind, IPGSCKotlinByteIterator, IPGSCKtor_httpUrl, IPGSCKotlinTriple, IPGSCKodein_diSearchSpecs, IPGSCKodein_diDIDefinition, IPGSCKodein_diScopeRegistry, IPGSCKtor_httpURLProtocol, IPGSCKodein_diDIDefining, IPGSCKodein_diReference;

@protocol IPGSCKotlinComparable, IPGSCRuntimeSqlDriver, IPGSCIPGDatabase, IPGSCICNativeConnector, IPGSCKodein_diDI, IPGSCKtor_httpParameters, IPGSCLogsEntityQueries, IPGSCRuntimeTransacter, IPGSCRuntimeSqlDriverSchema, IPGSCLogsEntity, IPGSCKotlinCoroutineContext, IPGSCBaseView, IPGSCCardDetailsView, IPGSCKotlinx_coroutines_coreCoroutineScope, IPGSCPurchaseView, IPGSCRefundView, IPGSCTransactionStatusView, IPGSCAndroidParcel, IPGSCKotlinx_serialization_runtimeKSerializer, IPGSCRuntimeSqlPreparedStatement, IPGSCRuntimeSqlCursor, IPGSCRuntimeCloseable, IPGSCKtor_ioCloseable, IPGSCKtor_client_coreHttpClientEngine, IPGSCKtor_client_coreHttpClientEngineCapability, IPGSCKtor_utilsAttributes, IPGSCKodein_diDIContainer, IPGSCKodein_diDIContext, IPGSCKodein_diDIAware, IPGSCKotlinMapEntry, IPGSCKtor_utilsStringValues, IPGSCKotlinx_serialization_runtimeDeserializationStrategy, IPGSCKotlinx_serialization_runtimeSerializationStrategy, IPGSCKotlinx_serialization_runtimeSerialModule, IPGSCKotlinx_serialization_runtimeSerialFormat, IPGSCKotlinx_serialization_runtimeStringFormat, IPGSCRuntimeQueryListener, IPGSCKotlinCoroutineContextElement, IPGSCKotlinCoroutineContextKey, IPGSCKotlinx_serialization_runtimeEncoder, IPGSCKotlinx_serialization_runtimeSerialDescriptor, IPGSCKotlinx_serialization_runtimeDecoder, IPGSCKodein_diDIBuilder, IPGSCKtor_client_coreHttpClientFeature, IPGSCKotlinContinuation, IPGSCKotlinContinuationInterceptor, IPGSCKotlinx_coroutines_coreRunnable, IPGSCKotlinSuspendFunction2, IPGSCKodein_diDITree, IPGSCKotlinLazy, IPGSCKotlinx_serialization_runtimeSerialModuleCollector, IPGSCKotlinKClass, IPGSCKotlinIterator, IPGSCKotlinx_serialization_runtimeCompositeEncoder, IPGSCKotlinAnnotation, IPGSCKotlinx_serialization_runtimeCompositeDecoder, IPGSCKodein_diDIBuilderDirectBinder, IPGSCKodein_diDIBuilderTypeBinder, IPGSCKodein_diContextTranslator, IPGSCKodein_diDIBuilderConstantBinder, IPGSCKodein_diDirectDI, IPGSCKodein_diDIContainerBuilder, IPGSCKodein_diDIBindBuilder, IPGSCKodein_diDIBindBuilderWithContext, IPGSCKodein_diScope, IPGSCKodein_diDIBindBuilderWithScope, IPGSCKotlinFunction, IPGSCKodein_diExternalSource, IPGSCKotlinKDeclarationContainer, IPGSCKotlinKAnnotatedElement, IPGSCKotlinKClassifier, IPGSCKodein_diDIBinding, IPGSCKodein_diDirectDIAware, IPGSCKodein_diDirectDIBase, IPGSCKodein_diBindingDI, IPGSCKodein_diDIBindingCopier, IPGSCKodein_diBinding, IPGSCKodein_diScopeCloseable, IPGSCKodein_diWithContext, IPGSCKodein_diSimpleBindingDI;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wnullability"

__attribute__((swift_name("KotlinBase")))
@interface IPGSCBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface IPGSCBase (IPGSCBaseCopying) <NSCopying>
@end;

__attribute__((swift_name("KotlinMutableSet")))
@interface IPGSCMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((swift_name("KotlinMutableDictionary")))
@interface IPGSCMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorIPGSCKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((swift_name("KotlinNumber")))
@interface IPGSCNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinByte")))
@interface IPGSCByte : IPGSCNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((swift_name("KotlinUByte")))
@interface IPGSCUByte : IPGSCNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((swift_name("KotlinShort")))
@interface IPGSCShort : IPGSCNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((swift_name("KotlinUShort")))
@interface IPGSCUShort : IPGSCNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((swift_name("KotlinInt")))
@interface IPGSCInt : IPGSCNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((swift_name("KotlinUInt")))
@interface IPGSCUInt : IPGSCNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((swift_name("KotlinLong")))
@interface IPGSCLong : IPGSCNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((swift_name("KotlinULong")))
@interface IPGSCULong : IPGSCNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((swift_name("KotlinFloat")))
@interface IPGSCFloat : IPGSCNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((swift_name("KotlinDouble")))
@interface IPGSCDouble : IPGSCNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((swift_name("KotlinBoolean")))
@interface IPGSCBoolean : IPGSCNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol IPGSCKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface IPGSCKotlinEnum : IPGSCBase <IPGSCKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(IPGSCKotlinEnum *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CurrencyEnum")))
@interface IPGSCCurrencyEnum : IPGSCKotlinEnum
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) IPGSCCurrencyEnum *eur __attribute__((swift_name("eur")));
@property (class, readonly) IPGSCCurrencyEnum *usd __attribute__((swift_name("usd")));
@property (class, readonly) IPGSCCurrencyEnum *bgn __attribute__((swift_name("bgn")));
@property (class, readonly) IPGSCCurrencyEnum *gbp __attribute__((swift_name("gbp")));
@property (class, readonly) IPGSCCurrencyEnum *hrk __attribute__((swift_name("hrk")));
@property (class, readonly) IPGSCCurrencyEnum *ron __attribute__((swift_name("ron")));
@property (class, readonly) IPGSCCurrencyEnum *chf __attribute__((swift_name("chf")));
@property (class, readonly) IPGSCCurrencyEnum *jpy __attribute__((swift_name("jpy")));
@property (class, readonly) IPGSCCurrencyEnum *pln __attribute__((swift_name("pln")));
@property (class, readonly) IPGSCCurrencyEnum *czk __attribute__((swift_name("czk")));
- (int32_t)compareToOther:(IPGSCCurrencyEnum *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *currency __attribute__((swift_name("currency")));
@property (readonly) BOOL isLeft __attribute__((swift_name("isLeft")));
@property (readonly) NSString *isoCode __attribute__((swift_name("isoCode")));
@property (readonly) NSString *symbol __attribute__((swift_name("symbol")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverFactory")))
@interface IPGSCDatabaseDriverFactory : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<IPGSCRuntimeSqlDriver>)createDriver __attribute__((swift_name("createDriver()")));
@end;

__attribute__((swift_name("ICNativeConnector")))
@protocol IPGSCICNativeConnector
@required
- (NSString *)encryptPKCS1PaddingEncodeBase64TextForEncryption:(NSString *)textForEncryption __attribute__((swift_name("encryptPKCS1PaddingEncodeBase64(textForEncryption:)")));
- (NSString *)generateSignaturePostParams:(NSString *)postParams __attribute__((swift_name("generateSignature(postParams:)")));
- (BOOL)verifySignatureResponse:(NSString *)response __attribute__((swift_name("verifySignature(response:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGProtocol")))
@interface IPGSCIPGProtocol : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGProtocol.Companion")))
@interface IPGSCIPGProtocolCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (readonly) int32_t ANDROID __attribute__((swift_name("ANDROID")));
@property (readonly) NSString *DEBUG_HOST __attribute__((swift_name("DEBUG_HOST")));
@property (readonly) NSString *DEBUG_HOST_ONLY __attribute__((swift_name("DEBUG_HOST_ONLY")));
@property (readonly) int32_t DEFAULT_KEY_INDEX __attribute__((swift_name("DEFAULT_KEY_INDEX")));
@property (readonly) NSString *ICARD_DIGITAL_WALLET_BACKEND_URL_DEBUG __attribute__((swift_name("ICARD_DIGITAL_WALLET_BACKEND_URL_DEBUG")));
@property (readonly) NSString *ICARD_DIGITAL_WALLET_BACKEND_URL_PROD __attribute__((swift_name("ICARD_DIGITAL_WALLET_BACKEND_URL_PROD")));
@property (readonly) int32_t IOS __attribute__((swift_name("IOS")));
@property (readonly) NSString *IPG_OLD_VERSION __attribute__((swift_name("IPG_OLD_VERSION")));
@property (readonly) NSString *IPG_VERSION __attribute__((swift_name("IPG_VERSION")));
@property (readonly) NSString *METHOD_3DS __attribute__((swift_name("METHOD_3DS")));
@property (readonly) NSString *METHOD_CHECK_CARD __attribute__((swift_name("METHOD_CHECK_CARD")));
@property (readonly) NSString *METHOD_GET_MERCHANT_TAX __attribute__((swift_name("METHOD_GET_MERCHANT_TAX")));
@property (readonly) NSString *METHOD_GET_TRANSACTION_STATUS __attribute__((swift_name("METHOD_GET_TRANSACTION_STATUS")));
@property (readonly) NSString *METHOD_IPG_SAVE_SDK_LOG __attribute__((swift_name("METHOD_IPG_SAVE_SDK_LOG")));
@property (readonly) NSString *METHOD_PURCHASE __attribute__((swift_name("METHOD_PURCHASE")));
@property (readonly) NSString *METHOD_REFUND __attribute__((swift_name("METHOD_REFUND")));
@property (readonly) NSString *METHOD_STORE_CARD __attribute__((swift_name("METHOD_STORE_CARD")));
@property (readonly) NSString *METHOD_STORE_CARD_UPDATE __attribute__((swift_name("METHOD_STORE_CARD_UPDATE")));
@property (readonly) NSString *PROD_HOST __attribute__((swift_name("PROD_HOST")));
@property (readonly) NSString *PROD_HOST_ONLY __attribute__((swift_name("PROD_HOST_ONLY")));
@property (readonly) NSString *SDK_VERSION __attribute__((swift_name("SDK_VERSION")));
@property (readonly) int32_t STATUS_ERROR_DUPLICATED __attribute__((swift_name("STATUS_ERROR_DUPLICATED")));
@property (readonly) int32_t STATUS_ERROR_EXCEEDED_LIMIT __attribute__((swift_name("STATUS_ERROR_EXCEEDED_LIMIT")));
@property (readonly) int32_t STATUS_ERROR_EXEECED_ACCOUNT_LIMITS __attribute__((swift_name("STATUS_ERROR_EXEECED_ACCOUNT_LIMITS")));
@property (readonly) int32_t STATUS_ERROR_INACTIVE_ACCOUNT_IDENTIFIER __attribute__((swift_name("STATUS_ERROR_INACTIVE_ACCOUNT_IDENTIFIER")));
@property (readonly) int32_t STATUS_ERROR_INACTIVE_MANDATE_REFERENCE __attribute__((swift_name("STATUS_ERROR_INACTIVE_MANDATE_REFERENCE")));
@property (readonly) int32_t STATUS_ERROR_INVALID_ACCOUNT_IDENTIFIER __attribute__((swift_name("STATUS_ERROR_INVALID_ACCOUNT_IDENTIFIER")));
@property (readonly) int32_t STATUS_ERROR_INVALID_MANDATE_REFERENCE __attribute__((swift_name("STATUS_ERROR_INVALID_MANDATE_REFERENCE")));
@property (readonly) int32_t STATUS_ERROR_INVALID_PARAMS __attribute__((swift_name("STATUS_ERROR_INVALID_PARAMS")));
@property (readonly) int32_t STATUS_ERROR_INVALID_REFERER __attribute__((swift_name("STATUS_ERROR_INVALID_REFERER")));
@property (readonly) int32_t STATUS_ERROR_INVALID_SID __attribute__((swift_name("STATUS_ERROR_INVALID_SID")));
@property (readonly) int32_t STATUS_ERROR_IPAY __attribute__((swift_name("STATUS_ERROR_IPAY")));
@property (readonly) int32_t STATUS_ERROR_MANDATE_ALREADY_REGISTERED __attribute__((swift_name("STATUS_ERROR_MANDATE_ALREADY_REGISTERED")));
@property (readonly) int32_t STATUS_ERROR_MISSING_REQ_PARAMS __attribute__((swift_name("STATUS_ERROR_MISSING_REQ_PARAMS")));
@property (readonly) int32_t STATUS_ERROR_NOT_SUFFICIENT_FUNDS __attribute__((swift_name("STATUS_ERROR_NOT_SUFFICIENT_FUNDS")));
@property (readonly) int32_t STATUS_ERROR_SIGNATURE_FAILED __attribute__((swift_name("STATUS_ERROR_SIGNATURE_FAILED")));
@property (readonly) int32_t STATUS_ERROR_TRANSACTION_AUTH_FAIL __attribute__((swift_name("STATUS_ERROR_TRANSACTION_AUTH_FAIL")));
@property (readonly) int32_t STATUS_ERROR_TRANSACTION_NOT_PERMITTED __attribute__((swift_name("STATUS_ERROR_TRANSACTION_NOT_PERMITTED")));
@property (readonly) int32_t STATUS_ERROR_UNDEFINED_ERROR __attribute__((swift_name("STATUS_ERROR_UNDEFINED_ERROR")));
@property (readonly) int32_t STATUS_ERROR_UNSUPPORTED_CALL __attribute__((swift_name("STATUS_ERROR_UNSUPPORTED_CALL")));
@property (readonly) int32_t STATUS_ERROR_WRONG_AMOUNT __attribute__((swift_name("STATUS_ERROR_WRONG_AMOUNT")));
@property (readonly) int32_t STATUS_INTERNAL_API_ERROR __attribute__((swift_name("STATUS_INTERNAL_API_ERROR")));
@property (readonly) int32_t STATUS_INTERNAL_COMMUNICATION_ERROR __attribute__((swift_name("STATUS_INTERNAL_COMMUNICATION_ERROR")));
@property (readonly) int32_t STATUS_INTERNAL_INVALID_PARAMS __attribute__((swift_name("STATUS_INTERNAL_INVALID_PARAMS")));
@property (readonly) int32_t STATUS_INTERNAL_SDK_NOT_INITIALIZED __attribute__((swift_name("STATUS_INTERNAL_SDK_NOT_INITIALIZED")));
@property (readonly) int32_t STATUS_INTERNAL_SIGNATURE_FAILED __attribute__((swift_name("STATUS_INTERNAL_SIGNATURE_FAILED")));
@property (readonly) int32_t STATUS_INTERNAL_TIMEOUT __attribute__((swift_name("STATUS_INTERNAL_TIMEOUT")));
@property (readonly) int32_t STATUS_SUCCESS __attribute__((swift_name("STATUS_SUCCESS")));
@property (readonly) NSString *TAG_BACKEND __attribute__((swift_name("TAG_BACKEND")));
@property (readonly) NSString *TAG_FROM_MOBILE __attribute__((swift_name("TAG_FROM_MOBILE")));
@property (readonly) NSString *TAG_IPG_VERSION __attribute__((swift_name("TAG_IPG_VERSION")));
@property (readonly) NSString *TAG_KEY_INDEX __attribute__((swift_name("TAG_KEY_INDEX")));
@property (readonly) NSString *TAG_LANGUAGE __attribute__((swift_name("TAG_LANGUAGE")));
@property (readonly) NSString *TAG_METHOD __attribute__((swift_name("TAG_METHOD")));
@property (readonly) NSString *TAG_MID __attribute__((swift_name("TAG_MID")));
@property (readonly) NSString *TAG_ORIGINATOR __attribute__((swift_name("TAG_ORIGINATOR")));
@property (readonly) NSString *TAG_OUTPUT_FORMAT __attribute__((swift_name("TAG_OUTPUT_FORMAT")));
@property (readonly) NSString *TAG_SDK_VERSION __attribute__((swift_name("TAG_SDK_VERSION")));
@property (readonly) NSString *TAG_SIGNATURE __attribute__((swift_name("TAG_SIGNATURE")));
@property (readonly) NSString *TAG_STATUS __attribute__((swift_name("TAG_STATUS")));
@property (readonly) NSString *TAG_STATUS_MSG __attribute__((swift_name("TAG_STATUS_MSG")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler")))
@interface IPGSCLogHandler : IPGSCBase
- (instancetype)initWithLogType:(int32_t)logType orderId:(NSString * _Nullable)orderId request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("init(logType:orderId:request:exception:)"))) __attribute__((objc_designated_initializer));
- (void)log __attribute__((swift_name("log()")));
- (void)sendSavedLogs __attribute__((swift_name("sendSavedLogs()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogHandler.Companion")))
@interface IPGSCLogHandlerCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (readonly) int32_t LOG_TYPE_BACK_FROM_CARD_DETAILS_SCREEN __attribute__((swift_name("LOG_TYPE_BACK_FROM_CARD_DETAILS_SCREEN")));
@property (readonly) int32_t LOG_TYPE_BACK_FROM_PAYMENT_PREVIEW_SCREEN __attribute__((swift_name("LOG_TYPE_BACK_FROM_PAYMENT_PREVIEW_SCREEN")));
@property (readonly) int32_t LOG_TYPE_BACK_FROM_SECURE_3D_SCREEN __attribute__((swift_name("LOG_TYPE_BACK_FROM_SECURE_3D_SCREEN")));
@property (readonly) int32_t LOG_TYPE_EXCEPTION __attribute__((swift_name("LOG_TYPE_EXCEPTION")));
@property (readonly) int32_t LOG_TYPE_SIGNATURE_FAILED __attribute__((swift_name("LOG_TYPE_SIGNATURE_FAILED")));
@property (readonly) int32_t LOG_TYPE_TIME_OUT __attribute__((swift_name("LOG_TYPE_TIME_OUT")));
@property (readonly) int32_t LOG_TYPE_TRACE_LOG __attribute__((swift_name("LOG_TYPE_TRACE_LOG")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformServiceLocator")))
@interface IPGSCPlatformServiceLocator : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)platformServiceLocator __attribute__((swift_name("init()")));
- (IPGSCKtor_client_coreHttpClient *)getHttpClientEngine __attribute__((swift_name("getHttpClientEngine()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServiceLocator")))
@interface IPGSCServiceLocator : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)serviceLocator __attribute__((swift_name("init()")));
- (void)setupCardPresenter __attribute__((swift_name("setupCardPresenter()")));
- (void)setupGetTransactionPresenter __attribute__((swift_name("setupGetTransactionPresenter()")));
- (void)setupIcardModel __attribute__((swift_name("setupIcardModel()")));
- (void)setupKodeinContainerSqlDriver:(id<IPGSCRuntimeSqlDriver>)sqlDriver __attribute__((swift_name("setupKodeinContainer(sqlDriver:)")));
- (void)setupPurchasePresenter __attribute__((swift_name("setupPurchasePresenter()")));
- (void)setupRefundPresenter __attribute__((swift_name("setupRefundPresenter()")));
@property id<IPGSCIPGDatabase> _Nullable database __attribute__((swift_name("database")));
@property IPGSCCardPresenter * _Nullable getCardPresenter __attribute__((swift_name("getCardPresenter")));
@property IPGSCIcard * _Nullable getIcardModel __attribute__((swift_name("getIcardModel")));
@property IPGSCPurchasePresenter * _Nullable getPurchasePresenter __attribute__((swift_name("getPurchasePresenter")));
@property IPGSCRefundPresenter * _Nullable getRefundPresenter __attribute__((swift_name("getRefundPresenter")));
@property IPGSCTransactionStatusPresenter * _Nullable getTransactionStatusPresenter __attribute__((swift_name("getTransactionStatusPresenter")));
@property id<IPGSCICNativeConnector> _Nullable icNativeConnector __attribute__((swift_name("icNativeConnector")));
@property id<IPGSCKodein_diDI> _Nullable kodeinContainer __attribute__((swift_name("kodeinContainer")));
@end;

__attribute__((swift_name("BaseApi")))
@interface IPGSCBaseApi : IPGSCBase
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCBaseRequestModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCBaseRequestModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCBaseResponseModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@property (readonly) id<IPGSCICNativeConnector> _Nullable iCNativeConnector __attribute__((swift_name("iCNativeConnector")));
@property (readonly) IPGSCKotlinx_serialization_runtimeJson *json __attribute__((swift_name("json")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckCardApi")))
@interface IPGSCCheckCardApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGCheckCardModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGCheckCardModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCCheckCardModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogApi")))
@interface IPGSCLogApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGLogModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGLogModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCLogResponseModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PurchaseApi")))
@interface IPGSCPurchaseApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGPurchaseModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGPurchaseModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCTransactionRefModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundApi")))
@interface IPGSCRefundApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGRefundModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGRefundModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCRefundTransactionModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreCardApi")))
@interface IPGSCStoreCardApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGStoreCardModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGStoreCardModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCStoredCardModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TaxApi")))
@interface IPGSCTaxApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGGetMerchantTax *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGGetMerchantTax *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCTaxModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusApi")))
@interface IPGSCTransactionStatusApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGTransactionStatusModel *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGTransactionStatusModel *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCTransactionStatusModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateCardApi")))
@interface IPGSCUpdateCardApi : IPGSCBaseApi
- (instancetype)initWithClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("init(client:)"))) __attribute__((objc_designated_initializer));
- (id<IPGSCKtor_httpParameters>)createFormParametersRequestModel:(IPGSCIPGStoredCardUpdate *)requestModel __attribute__((swift_name("createFormParameters(requestModel:)")));
- (NSString *)createUrlEncodedParametersRequestModel:(IPGSCIPGStoredCardUpdate *)requestModel __attribute__((swift_name("createUrlEncodedParameters(requestModel:)")));
- (IPGSCStoredCardModel *)processResponseBody:(NSString *)body __attribute__((swift_name("processResponse(body:)")));
@end;

__attribute__((swift_name("RuntimeTransacter")))
@protocol IPGSCRuntimeTransacter
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(IPGSCRuntimeTransacterTransaction *))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
@end;

__attribute__((swift_name("IPGDatabase")))
@protocol IPGSCIPGDatabase <IPGSCRuntimeTransacter>
@required
@property (readonly) id<IPGSCLogsEntityQueries> logsEntityQueries __attribute__((swift_name("logsEntityQueries")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGDatabaseCompanion")))
@interface IPGSCIPGDatabaseCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCIPGDatabase>)invokeDriver:(id<IPGSCRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<IPGSCRuntimeSqlDriverSchema> Schema __attribute__((swift_name("Schema")));
@end;

__attribute__((swift_name("LogsEntity")))
@protocol IPGSCLogsEntity
@required
@property (readonly) NSString * _Nullable exception __attribute__((swift_name("exception")));
@property (readonly) int64_t log_type __attribute__((swift_name("log_type")));
@property (readonly) NSString *operation_id __attribute__((swift_name("operation_id")));
@property (readonly) NSString * _Nullable order_id __attribute__((swift_name("order_id")));
@property (readonly) NSString * _Nullable request __attribute__((swift_name("request")));
@property (readonly) IPGSCLong * _Nullable request_timestamp __attribute__((swift_name("request_timestamp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogsEntityImpl")))
@interface IPGSCLogsEntityImpl : IPGSCBase <IPGSCLogsEntity>
- (instancetype)initWithOperation_id:(NSString *)operation_id log_type:(int64_t)log_type order_id:(NSString * _Nullable)order_id request_timestamp:(IPGSCLong * _Nullable)request_timestamp request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("init(operation_id:log_type:order_id:request_timestamp:request:exception:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int64_t)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (IPGSCLong * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString * _Nullable)component5 __attribute__((swift_name("component5()")));
- (NSString * _Nullable)component6 __attribute__((swift_name("component6()")));
- (IPGSCLogsEntityImpl *)doCopyOperation_id:(NSString *)operation_id log_type:(int64_t)log_type order_id:(NSString * _Nullable)order_id request_timestamp:(IPGSCLong * _Nullable)request_timestamp request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("doCopy(operation_id:log_type:order_id:request_timestamp:request:exception:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable exception __attribute__((swift_name("exception")));
@property (readonly) int64_t log_type __attribute__((swift_name("log_type")));
@property (readonly) NSString *operation_id __attribute__((swift_name("operation_id")));
@property (readonly) NSString * _Nullable order_id __attribute__((swift_name("order_id")));
@property (readonly) NSString * _Nullable request __attribute__((swift_name("request")));
@property (readonly) IPGSCLong * _Nullable request_timestamp __attribute__((swift_name("request_timestamp")));
@end;

__attribute__((swift_name("LogsEntityQueries")))
@protocol IPGSCLogsEntityQueries <IPGSCRuntimeTransacter>
@required
- (void)deleteLogByOperationIdOperation_id:(NSString *)operation_id __attribute__((swift_name("deleteLogByOperationId(operation_id:)")));
- (void)insertLogOperation_id:(NSString *)operation_id log_type:(int64_t)log_type order_id:(NSString * _Nullable)order_id request_timestamp:(IPGSCLong * _Nullable)request_timestamp request:(NSString * _Nullable)request exception:(NSString * _Nullable)exception __attribute__((swift_name("insertLog(operation_id:log_type:order_id:request_timestamp:request:exception:)")));
- (IPGSCRuntimeQuery *)selectAllLogs __attribute__((swift_name("selectAllLogs()")));
- (IPGSCRuntimeQuery *)selectAllLogsMapper:(id (^)(NSString *, IPGSCLong *, NSString * _Nullable, IPGSCLong * _Nullable, NSString * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("selectAllLogs(mapper:)")));
@end;

__attribute__((swift_name("BasePresenter")))
@interface IPGSCBasePresenter : IPGSCBase
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (void)attachViewView:(id _Nullable)view __attribute__((swift_name("attachView(view:)")));
- (void)detachView __attribute__((swift_name("detachView()")));
- (void)onViewAttachedView:(id _Nullable)view __attribute__((swift_name("onViewAttached(view:)")));
- (void)onViewDetached __attribute__((swift_name("onViewDetached()")));
@property IPGSCPresenterCoroutineScope *scope __attribute__((swift_name("scope")));
@property id _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("BaseView")))
@protocol IPGSCBaseView
@required
- (void)onErrorResponseModel:(IPGSCBaseResponseModel *)responseModel __attribute__((swift_name("onError(responseModel:)")));
- (void)onExceptionThrowable:(IPGSCKotlinThrowable *)throwable __attribute__((swift_name("onException(throwable:)")));
- (void)setProgressShow:(BOOL)show __attribute__((swift_name("setProgress(show:)")));
@end;

__attribute__((swift_name("CardDetailsView")))
@protocol IPGSCCardDetailsView <IPGSCBaseView>
@required
- (void)cardDetailsCheckCardModel:(IPGSCCheckCardModel *)checkCardModel __attribute__((swift_name("cardDetails(checkCardModel:)")));
- (void)cardStoredStoredCardModel:(IPGSCStoredCardModel *)storedCardModel __attribute__((swift_name("cardStored(storedCardModel:)")));
- (void)cardUpdatedStoredCardModel:(IPGSCStoredCardModel *)storedCardModel __attribute__((swift_name("cardUpdated(storedCardModel:)")));
- (void)invalidPan __attribute__((swift_name("invalidPan()")));
- (void)storeCardAndPurchaseStoredCardModel:(IPGSCStoredCardModel *)storedCardModel __attribute__((swift_name("storeCardAndPurchase(storedCardModel:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CardPresenter")))
@interface IPGSCCardPresenter : IPGSCBasePresenter
- (instancetype)initWithStoreCardUseCase:(IPGSCStoreCardUseCase *)storeCardUseCase updateCardUseCase:(IPGSCStoredCardUpdateUseCase *)updateCardUseCase checkCardUseCase:(IPGSCCheckCardUseCase *)checkCardUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(storeCardUseCase:updateCardUseCase:checkCardUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)attachViewView:(id<IPGSCCardDetailsView>)view __attribute__((swift_name("attachView(view:)")));
- (void)checkCardCardNumber:(NSString *)cardNumber orderId:(NSString *)orderId __attribute__((swift_name("checkCard(cardNumber:orderId:)")));
- (void)logBackPressedFromCardDetailsOrderId:(NSString *)orderId __attribute__((swift_name("logBackPressedFromCardDetails(orderId:)")));
- (void)onViewAttachedView:(id<IPGSCCardDetailsView>)view __attribute__((swift_name("onViewAttached(view:)")));
- (void)storeCardIpgStoreCardModel:(IPGSCIPGStoreCardModel *)ipgStoreCardModel __attribute__((swift_name("storeCard(ipgStoreCardModel:)")));
- (void)updateCardIpgStoredCardUpdate:(IPGSCIPGStoredCardUpdate *)ipgStoredCardUpdate __attribute__((swift_name("updateCard(ipgStoredCardUpdate:)")));
@property id<IPGSCCardDetailsView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol IPGSCKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<IPGSCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PresenterCoroutineScope")))
@interface IPGSCPresenterCoroutineScope : IPGSCBase <IPGSCKotlinx_coroutines_coreCoroutineScope>
- (instancetype)initWithContext:(id<IPGSCKotlinCoroutineContext>)context __attribute__((swift_name("init(context:)"))) __attribute__((objc_designated_initializer));
- (void)viewDetached __attribute__((swift_name("viewDetached()")));
@property (readonly) id<IPGSCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PurchasePresenter")))
@interface IPGSCPurchasePresenter : IPGSCBasePresenter
- (instancetype)initWithPurchaseUseCase:(IPGSCPurchaseUseCase *)purchaseUseCase getMerchantTaxUseCase:(IPGSCGetMerchantTaxUseCase *)getMerchantTaxUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(purchaseUseCase:getMerchantTaxUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)attachViewView:(id<IPGSCPurchaseView>)view __attribute__((swift_name("attachView(view:)")));
- (void)getMerchantTaxOrderId:(NSString * _Nullable)orderId token:(NSString * _Nullable)token pan:(NSString * _Nullable)pan __attribute__((swift_name("getMerchantTax(orderId:token:pan:)")));
- (void)logBackPressedFromPaymentPreviewOrderId:(NSString *)orderId __attribute__((swift_name("logBackPressedFromPaymentPreview(orderId:)")));
- (void)onViewAttachedView:(id<IPGSCPurchaseView>)view __attribute__((swift_name("onViewAttached(view:)")));
- (void)purchaseIpgPurchaseModel:(IPGSCIPGPurchaseModel *)ipgPurchaseModel __attribute__((swift_name("purchase(ipgPurchaseModel:)")));
@property id<IPGSCPurchaseView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("PurchaseView")))
@protocol IPGSCPurchaseView <IPGSCBaseView>
@required
- (void)taxReceivedTaxModel:(IPGSCTaxModel *)taxModel __attribute__((swift_name("taxReceived(taxModel:)")));
- (void)transactionReferenceTransactionRefModel:(IPGSCTransactionRefModel *)transactionRefModel __attribute__((swift_name("transactionReference(transactionRefModel:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundPresenter")))
@interface IPGSCRefundPresenter : IPGSCBasePresenter
- (instancetype)initWithRefundUseCase:(IPGSCRefundUseCase *)refundUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(refundUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)attachViewView:(id<IPGSCRefundView>)view __attribute__((swift_name("attachView(view:)")));
- (void)onViewAttachedView:(id<IPGSCRefundView>)view __attribute__((swift_name("onViewAttached(view:)")));
- (void)refundIpgRefundModel:(IPGSCIPGRefundModel *)ipgRefundModel __attribute__((swift_name("refund(ipgRefundModel:)")));
@property id<IPGSCRefundView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("RefundView")))
@protocol IPGSCRefundView <IPGSCBaseView>
@required
- (void)transactionReferenceReceivedTransactionRefModel:(IPGSCTransactionRefModel *)transactionRefModel __attribute__((swift_name("transactionReferenceReceived(transactionRefModel:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusPresenter")))
@interface IPGSCTransactionStatusPresenter : IPGSCBasePresenter
- (instancetype)initWithGetTransactionStatusUseCase:(IPGSCGetTransactionStatusUseCase *)getTransactionStatusUseCase coroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(getTransactionStatusUseCase:coroutineContext:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCoroutineContext:(id<IPGSCKotlinCoroutineContext>)coroutineContext __attribute__((swift_name("init(coroutineContext:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)attachViewView:(id<IPGSCTransactionStatusView>)view __attribute__((swift_name("attachView(view:)")));
- (void)getTransactionStatusOrderId:(NSString *)orderId __attribute__((swift_name("getTransactionStatus(orderId:)")));
- (void)onViewAttachedView:(id<IPGSCTransactionStatusView>)view __attribute__((swift_name("onViewAttached(view:)")));
@property id<IPGSCTransactionStatusView> _Nullable view __attribute__((swift_name("view")));
@end;

__attribute__((swift_name("TransactionStatusView")))
@protocol IPGSCTransactionStatusView <IPGSCBaseView>
@required
- (void)transactionStatusTransactionStatus:(IPGSCTransactionStatusModel *)transactionStatus __attribute__((swift_name("transactionStatus(transactionStatus:)")));
@end;

__attribute__((swift_name("AndroidParcel")))
@protocol IPGSCAndroidParcel
@required
@end;

__attribute__((swift_name("BaseUseCase")))
@interface IPGSCBaseUseCase : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseUseCase.None")))
@interface IPGSCBaseUseCaseNone : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)none __attribute__((swift_name("init()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckCardUseCase")))
@interface IPGSCCheckCardUseCase : IPGSCBaseUseCase
- (instancetype)initWithCheckCardApi:(IPGSCCheckCardApi *)checkCardApi __attribute__((swift_name("init(checkCardApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetMerchantTaxUseCase")))
@interface IPGSCGetMerchantTaxUseCase : IPGSCBaseUseCase
- (instancetype)initWithTaxApi:(IPGSCTaxApi *)taxApi __attribute__((swift_name("init(taxApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetTransactionStatusUseCase")))
@interface IPGSCGetTransactionStatusUseCase : IPGSCBaseUseCase
- (instancetype)initWithTransactionStatusApi:(IPGSCTransactionStatusApi *)transactionStatusApi __attribute__((swift_name("init(transactionStatusApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogUseCase")))
@interface IPGSCLogUseCase : IPGSCBaseUseCase
- (instancetype)initWithLogApi:(IPGSCLogApi *)logApi __attribute__((swift_name("init(logApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PurchaseUseCase")))
@interface IPGSCPurchaseUseCase : IPGSCBaseUseCase
- (instancetype)initWithPurchaseApi:(IPGSCPurchaseApi *)purchaseApi __attribute__((swift_name("init(purchaseApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundUseCase")))
@interface IPGSCRefundUseCase : IPGSCBaseUseCase
- (instancetype)initWithRefundApi:(IPGSCRefundApi *)refundApi __attribute__((swift_name("init(refundApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoreCardUseCase")))
@interface IPGSCStoreCardUseCase : IPGSCBaseUseCase
- (instancetype)initWithStoreCardApi:(IPGSCStoreCardApi *)storeCardApi __attribute__((swift_name("init(storeCardApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoredCardUpdateUseCase")))
@interface IPGSCStoredCardUpdateUseCase : IPGSCBaseUseCase
- (instancetype)initWithUpdateCardApi:(IPGSCUpdateCardApi *)updateCardApi __attribute__((swift_name("init(updateCardApi:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AcqSchemeEnum")))
@interface IPGSCAcqSchemeEnum : IPGSCKotlinEnum
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) IPGSCAcqSchemeEnum *mastercard __attribute__((swift_name("mastercard")));
@property (class, readonly) IPGSCAcqSchemeEnum *visa __attribute__((swift_name("visa")));
@property (class, readonly) IPGSCAcqSchemeEnum *maestro __attribute__((swift_name("maestro")));
- (int32_t)compareToOther:(IPGSCAcqSchemeEnum *)other __attribute__((swift_name("compareTo(other:)")));
@property (readonly) NSString *acqName __attribute__((swift_name("acqName")));
@property (readonly) NSString *schemeName __attribute__((swift_name("schemeName")));
@end;

__attribute__((swift_name("BaseResponseModel")))
@interface IPGSCBaseResponseModel : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@end;

__attribute__((swift_name("CartItemModel")))
@interface IPGSCCartItemModel : IPGSCBase <IPGSCAndroidParcel>
- (instancetype)initWithArticle:(NSString *)article quantity:(int32_t)quantity price:(double)price __attribute__((swift_name("init(article:quantity:price:)"))) __attribute__((objc_designated_initializer));
@property double amount __attribute__((swift_name("amount")));
@property NSString *article __attribute__((swift_name("article")));
@property NSString *currency __attribute__((swift_name("currency")));
@property double price __attribute__((swift_name("price")));
@property int32_t quantity __attribute__((swift_name("quantity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CartItemModel.Companion")))
@interface IPGSCCartItemModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("CheckCardModel")))
@interface IPGSCCheckCardModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString * _Nullable acqScheme __attribute__((swift_name("acqScheme")));
@property NSString * _Nullable brand __attribute__((swift_name("brand")));
@property NSString * _Nullable issueCountry __attribute__((swift_name("issueCountry")));
@property NSString * _Nullable issueRegion __attribute__((swift_name("issueRegion")));
@property NSString * _Nullable productId __attribute__((swift_name("productId")));
@property NSString *qualifier __attribute__((swift_name("qualifier")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CheckCardModel.Companion")))
@interface IPGSCCheckCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("Either")))
@interface IPGSCEither : IPGSCBase
- (id _Nullable)foldFailed:(id _Nullable (^)(id _Nullable))failed succeeded:(id _Nullable (^)(id _Nullable))succeeded errorr:(id _Nullable (^)(id _Nullable))errorr __attribute__((swift_name("fold(failed:succeeded:errorr:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Either.Error")))
@interface IPGSCEitherError : IPGSCEither
- (instancetype)initWithError:(id _Nullable)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)component1 __attribute__((swift_name("component1()")));
- (IPGSCEitherError *)doCopyError:(id _Nullable)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (id _Nullable)foldFailed:(id _Nullable (^)(IPGSCKotlinNothing *))failed succeeded:(id _Nullable (^)(IPGSCKotlinNothing *))succeeded errorr:(id _Nullable (^)(id _Nullable))errorr __attribute__((swift_name("fold(failed:succeeded:errorr:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id _Nullable error __attribute__((swift_name("error")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Either.Failure")))
@interface IPGSCEitherFailure : IPGSCEither
- (instancetype)initWithFailure:(id _Nullable)failure __attribute__((swift_name("init(failure:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)component1 __attribute__((swift_name("component1()")));
- (IPGSCEitherFailure *)doCopyFailure:(id _Nullable)failure __attribute__((swift_name("doCopy(failure:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (id _Nullable)foldFailed:(id _Nullable (^)(id _Nullable))failed succeeded:(id _Nullable (^)(IPGSCKotlinNothing *))succeeded errorr:(id _Nullable (^)(IPGSCKotlinNothing *))errorr __attribute__((swift_name("fold(failed:succeeded:errorr:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id _Nullable failure __attribute__((swift_name("failure")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Either.Success")))
@interface IPGSCEitherSuccess : IPGSCEither
- (instancetype)initWithSuccess:(id _Nullable)success __attribute__((swift_name("init(success:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)component1 __attribute__((swift_name("component1()")));
- (IPGSCEitherSuccess *)doCopySuccess:(id _Nullable)success __attribute__((swift_name("doCopy(success:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (id _Nullable)foldFailed:(id _Nullable (^)(IPGSCKotlinNothing *))failed succeeded:(id _Nullable (^)(id _Nullable))succeeded errorr:(id _Nullable (^)(IPGSCKotlinNothing *))errorr __attribute__((swift_name("fold(failed:succeeded:errorr:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id _Nullable success __attribute__((swift_name("success")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Icard")))
@interface IPGSCIcard : IPGSCBase
- (instancetype)initWithMid:(NSString * _Nullable)mid currency:(NSString * _Nullable)currency clientPrivateKey:(NSString * _Nullable)clientPrivateKey iCardPublicKey:(NSString * _Nullable)iCardPublicKey taxUrl:(NSString *)taxUrl isSandbox:(BOOL)isSandbox originator:(NSString * _Nullable)originator backendUrl:(NSString *)backendUrl billingAddressCity:(NSString *)billingAddressCity billingAddressCountry:(NSString *)billingAddressCountry billingAddress1:(NSString *)billingAddress1 billingAddress2:(NSString *)billingAddress2 billingAddress3:(NSString *)billingAddress3 name:(NSString *)name emailAddress:(NSString *)emailAddress billingAddressPostCode:(NSString *)billingAddressPostCode language:(NSString *)language keyIndex:(int32_t)keyIndex __attribute__((swift_name("init(mid:currency:clientPrivateKey:iCardPublicKey:taxUrl:isSandbox:originator:backendUrl:billingAddressCity:billingAddressCountry:billingAddress1:billingAddress2:billingAddress3:name:emailAddress:billingAddressPostCode:language:keyIndex:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString *)component10 __attribute__((swift_name("component10()")));
- (NSString *)component11 __attribute__((swift_name("component11()")));
- (NSString *)component12 __attribute__((swift_name("component12()")));
- (NSString *)component13 __attribute__((swift_name("component13()")));
- (NSString *)component14 __attribute__((swift_name("component14()")));
- (NSString *)component15 __attribute__((swift_name("component15()")));
- (NSString *)component16 __attribute__((swift_name("component16()")));
- (NSString *)component17 __attribute__((swift_name("component17()")));
- (int32_t)component18 __attribute__((swift_name("component18()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (BOOL)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSString *)component8 __attribute__((swift_name("component8()")));
- (NSString *)component9 __attribute__((swift_name("component9()")));
- (IPGSCIcard *)doCopyMid:(NSString * _Nullable)mid currency:(NSString * _Nullable)currency clientPrivateKey:(NSString * _Nullable)clientPrivateKey iCardPublicKey:(NSString * _Nullable)iCardPublicKey taxUrl:(NSString *)taxUrl isSandbox:(BOOL)isSandbox originator:(NSString * _Nullable)originator backendUrl:(NSString *)backendUrl billingAddressCity:(NSString *)billingAddressCity billingAddressCountry:(NSString *)billingAddressCountry billingAddress1:(NSString *)billingAddress1 billingAddress2:(NSString *)billingAddress2 billingAddress3:(NSString *)billingAddress3 name:(NSString *)name emailAddress:(NSString *)emailAddress billingAddressPostCode:(NSString *)billingAddressPostCode language:(NSString *)language keyIndex:(int32_t)keyIndex __attribute__((swift_name("doCopy(mid:currency:clientPrivateKey:iCardPublicKey:taxUrl:isSandbox:originator:backendUrl:billingAddressCity:billingAddressCountry:billingAddress1:billingAddress2:billingAddress3:name:emailAddress:billingAddressPostCode:language:keyIndex:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isICardDigitalWallet __attribute__((swift_name("isICardDigitalWallet()")));
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *backendUrl __attribute__((swift_name("backendUrl")));
@property NSString *billingAddress1 __attribute__((swift_name("billingAddress1")));
@property NSString *billingAddress2 __attribute__((swift_name("billingAddress2")));
@property NSString *billingAddress3 __attribute__((swift_name("billingAddress3")));
@property NSString *billingAddressCity __attribute__((swift_name("billingAddressCity")));
@property NSString *billingAddressCountry __attribute__((swift_name("billingAddressCountry")));
@property NSString *billingAddressPostCode __attribute__((swift_name("billingAddressPostCode")));
@property NSString * _Nullable clientPrivateKey __attribute__((swift_name("clientPrivateKey")));
@property NSString * _Nullable currency __attribute__((swift_name("currency")));
@property NSString *emailAddress __attribute__((swift_name("emailAddress")));
@property NSString * _Nullable iCardPublicKey __attribute__((swift_name("iCardPublicKey")));
@property BOOL isSandbox __attribute__((swift_name("isSandbox")));
@property int32_t keyIndex __attribute__((swift_name("keyIndex")));
@property NSString *language __attribute__((swift_name("language")));
@property NSString * _Nullable mid __attribute__((swift_name("mid")));
@property NSString *name __attribute__((swift_name("name")));
@property NSString * _Nullable originator __attribute__((swift_name("originator")));
@property NSString *taxUrl __attribute__((swift_name("taxUrl")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Icard.Companion")))
@interface IPGSCIcardCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogResponseModel")))
@interface IPGSCLogResponseModel : IPGSCBaseResponseModel
- (instancetype)initWithOperationId:(NSString *)operationId status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(operationId:status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (IPGSCLogResponseModel *)doCopyOperationId:(NSString *)operationId status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("doCopy(operationId:status:statusMessage:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *operationId __attribute__((swift_name("operationId")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LogResponseModel.Companion")))
@interface IPGSCLogResponseModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("RefundTransactionModel")))
@interface IPGSCRefundTransactionModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property double amount __attribute__((swift_name("amount")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RefundTransactionModel.Companion")))
@interface IPGSCRefundTransactionModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("StoredCardModel")))
@interface IPGSCStoredCardModel : IPGSCBaseResponseModel <IPGSCAndroidParcel>
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *approval __attribute__((swift_name("approval")));
@property NSString * _Nullable cardCustomName __attribute__((swift_name("cardCustomName")));
@property NSString * _Nullable cardExpDate __attribute__((swift_name("cardExpDate")));
@property NSString * _Nullable cardToken __attribute__((swift_name("cardToken")));
@property int32_t cardType __attribute__((swift_name("cardType")));
@property NSString * _Nullable maskedPan __attribute__((swift_name("maskedPan")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StoredCardModel.Companion")))
@interface IPGSCStoredCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("TaxModel")))
@interface IPGSCTaxModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *maskedPan __attribute__((swift_name("maskedPan")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property double tax __attribute__((swift_name("tax")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TaxModel.Companion")))
@interface IPGSCTaxModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("TransactionRefModel")))
@interface IPGSCTransactionRefModel : IPGSCBaseResponseModel
- (instancetype)initWithStatus:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)setTransReferenceValue:(NSString *)value __attribute__((swift_name("setTransReference(value:)")));
@property double amount __attribute__((swift_name("amount")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionRefModel.Companion")))
@interface IPGSCTransactionRefModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusModel")))
@interface IPGSCTransactionStatusModel : IPGSCBaseResponseModel
- (instancetype)initWithTranStatus:(int32_t)tranStatus transactionReference:(NSString *)transactionReference status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("init(tranStatus:transactionReference:status:statusMessage:signature:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (IPGSCTransactionStatusModel *)doCopyTranStatus:(int32_t)tranStatus transactionReference:(NSString *)transactionReference status:(int32_t)status statusMessage:(NSString *)statusMessage signature:(NSString *)signature __attribute__((swift_name("doCopy(tranStatus:transactionReference:status:statusMessage:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *signature __attribute__((swift_name("signature")));
@property int32_t status __attribute__((swift_name("status")));
@property NSString *statusMessage __attribute__((swift_name("statusMessage")));
@property int32_t tranStatus __attribute__((swift_name("tranStatus")));
@property NSString *transactionReference __attribute__((swift_name("transactionReference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TransactionStatusModel.Companion")))
@interface IPGSCTransactionStatusModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("BaseRequestModel")))
@interface IPGSCBaseRequestModel : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseRequestModel.Companion")))
@interface IPGSCBaseRequestModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseRequestParameters")))
@interface IPGSCBaseRequestParameters : IPGSCBase
- (instancetype)initWithIpgVersion:(NSString *)ipgVersion sdkVersion:(NSString * _Nullable)sdkVersion outputFormat:(NSString *)outputFormat backEnd:(NSString *)backEnd deviceName:(int32_t)deviceName deviceOsVersion:(NSString *)deviceOsVersion deviceModel:(NSString *)deviceModel __attribute__((swift_name("init(ipgVersion:sdkVersion:outputFormat:backEnd:deviceName:deviceOsVersion:deviceModel:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (int32_t)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (IPGSCBaseRequestParameters *)doCopyIpgVersion:(NSString *)ipgVersion sdkVersion:(NSString * _Nullable)sdkVersion outputFormat:(NSString *)outputFormat backEnd:(NSString *)backEnd deviceName:(int32_t)deviceName deviceOsVersion:(NSString *)deviceOsVersion deviceModel:(NSString *)deviceModel __attribute__((swift_name("doCopy(ipgVersion:sdkVersion:outputFormat:backEnd:deviceName:deviceOsVersion:deviceModel:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *backEnd __attribute__((swift_name("backEnd")));
@property (readonly) NSString *deviceModel __attribute__((swift_name("deviceModel")));
@property (readonly) int32_t deviceName __attribute__((swift_name("deviceName")));
@property (readonly) NSString *deviceOsVersion __attribute__((swift_name("deviceOsVersion")));
@property (readonly) NSString *ipgVersion __attribute__((swift_name("ipgVersion")));
@property (readonly) NSString *outputFormat __attribute__((swift_name("outputFormat")));
@property (readonly) NSString * _Nullable sdkVersion __attribute__((swift_name("sdkVersion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseRequestParameters.Companion")))
@interface IPGSCBaseRequestParametersCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPG3dsModel")))
@interface IPGSCIPG3dsModel : IPGSCBaseRequestModel
- (instancetype)initWithCardholderName:(NSString *)cardholderName expiryMonth:(NSString *)expiryMonth expiryYear:(NSString *)expiryYear orderId:(NSString *)orderId amount:(NSString *)amount method:(NSString *)method __attribute__((swift_name("init(cardholderName:expiryMonth:expiryYear:orderId:amount:method:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (NSString *)toFormData __attribute__((swift_name("toFormData()")));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *cardToken __attribute__((swift_name("cardToken")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *expiryMonth __attribute__((swift_name("expiryMonth")));
@property NSString *expiryYear __attribute__((swift_name("expiryYear")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPG3dsModel.Companion")))
@interface IPGSCIPG3dsModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGCheckCardModel")))
@interface IPGSCIPGCheckCardModel : IPGSCBaseRequestModel
- (instancetype)initWithMethod:(NSString *)method orderId:(NSString *)orderId cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(method:orderId:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGCheckCardModel.Companion")))
@interface IPGSCIPGCheckCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGGetMerchantTax")))
@interface IPGSCIPGGetMerchantTax : IPGSCBaseRequestModel
- (instancetype)initWithOrderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(orderId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@property NSString *token __attribute__((swift_name("token")));
@property (readonly) NSString *urlTax __attribute__((swift_name("urlTax")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGGetMerchantTax.Companion")))
@interface IPGSCIPGGetMerchantTaxCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGLogModel")))
@interface IPGSCIPGLogModel : IPGSCBaseRequestModel
- (instancetype)initWithMethod:(NSString *)method orderId:(NSString *)orderId cardholderName:(NSString *)cardholderName logType:(int32_t)logType operationId:(NSString *)operationId requestTimestamp:(int64_t)requestTimestamp request:(NSString *)request exceptionStackTrace:(NSString *)exceptionStackTrace __attribute__((swift_name("init(method:orderId:cardholderName:logType:operationId:requestTimestamp:request:exceptionStackTrace:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (int32_t)component4 __attribute__((swift_name("component4()")));
- (NSString *)component5 __attribute__((swift_name("component5()")));
- (int64_t)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (NSString *)component8 __attribute__((swift_name("component8()")));
- (IPGSCIPGLogModel *)doCopyMethod:(NSString *)method orderId:(NSString *)orderId cardholderName:(NSString *)cardholderName logType:(int32_t)logType operationId:(NSString *)operationId requestTimestamp:(int64_t)requestTimestamp request:(NSString *)request exceptionStackTrace:(NSString *)exceptionStackTrace __attribute__((swift_name("doCopy(method:orderId:cardholderName:logType:operationId:requestTimestamp:request:exceptionStackTrace:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *exceptionStackTrace __attribute__((swift_name("exceptionStackTrace")));
@property int32_t logType __attribute__((swift_name("logType")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *operationId __attribute__((swift_name("operationId")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *request __attribute__((swift_name("request")));
@property int64_t requestTimestamp __attribute__((swift_name("requestTimestamp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGLogModel.Companion")))
@interface IPGSCIPGLogModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGPurchaseModel")))
@interface IPGSCIPGPurchaseModel : IPGSCBaseRequestModel <IPGSCAndroidParcel>
- (instancetype)initWithCardItems:(NSArray<IPGSCCartItemModel *> *)cardItems orderId:(NSString *)orderId expiryMonth:(NSString *)expiryMonth expiryYear:(NSString *)expiryYear eci:(NSString *)eci avv:(NSString *)avv xid:(NSString *)xid secure3dTransactionId:(NSString *)secure3dTransactionId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(cardItems:orderId:expiryMonth:expiryYear:eci:avv:xid:secure3dTransactionId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *avv __attribute__((swift_name("avv")));
@property NSArray<IPGSCCartItemModel *> *cardItems __attribute__((swift_name("cardItems")));
@property NSString * _Nullable cardToken __attribute__((swift_name("cardToken")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *eci __attribute__((swift_name("eci")));
@property NSString *expiryMonth __attribute__((swift_name("expiryMonth")));
@property NSString *expiryYear __attribute__((swift_name("expiryYear")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString * _Nullable pan __attribute__((swift_name("pan")));
@property NSString *secure3dTransactionId __attribute__((swift_name("secure3dTransactionId")));
@property double totalAmount __attribute__((swift_name("totalAmount")));
@property NSString *xid __attribute__((swift_name("xid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGPurchaseModel.Companion")))
@interface IPGSCIPGPurchaseModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGRefundModel")))
@interface IPGSCIPGRefundModel : IPGSCBaseRequestModel
- (instancetype)initWithTransactionRef:(NSString *)transactionRef amount:(NSString *)amount orderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(transactionRef:amount:orderId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *transactionRef __attribute__((swift_name("transactionRef")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGRefundModel.Companion")))
@interface IPGSCIPGRefundModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGStoreCardModel")))
@interface IPGSCIPGStoreCardModel : IPGSCBaseRequestModel <IPGSCAndroidParcel>
- (instancetype)initWithCardholderName:(NSString *)cardholderName customName:(NSString *)customName expiryMonth:(NSString *)expiryMonth expiryYear:(NSString *)expiryYear eci:(NSString *)eci avv:(NSString *)avv xid:(NSString *)xid secure3dTransactionId:(NSString *)secure3dTransactionId cardVerification:(NSString *)cardVerification orderId:(NSString *)orderId amount:(NSString *)amount cardItems:(NSArray<IPGSCCartItemModel *> *)cardItems method:(NSString *)method __attribute__((swift_name("init(cardholderName:customName:expiryMonth:expiryYear:eci:avv:xid:secure3dTransactionId:cardVerification:orderId:amount:cardItems:method:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *avv __attribute__((swift_name("avv")));
@property NSArray<IPGSCCartItemModel *> *cardItems __attribute__((swift_name("cardItems")));
@property NSString *cardToken __attribute__((swift_name("cardToken")));
@property NSString *cardVerification __attribute__((swift_name("cardVerification")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *customName __attribute__((swift_name("customName")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *eci __attribute__((swift_name("eci")));
@property NSString *expiryMonth __attribute__((swift_name("expiryMonth")));
@property NSString *expiryYear __attribute__((swift_name("expiryYear")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@property NSString *secure3dTransactionId __attribute__((swift_name("secure3dTransactionId")));
@property NSString *xid __attribute__((swift_name("xid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGStoreCardModel.Companion")))
@interface IPGSCIPGStoreCardModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("IPGStoredCardUpdate")))
@interface IPGSCIPGStoredCardUpdate : IPGSCBaseRequestModel
- (instancetype)initWithNote:(NSString *)note token:(NSString *)token method:(NSString *)method cardholderName:(NSString *)cardholderName customName:(NSString *)customName eci:(NSString *)eci avv:(NSString *)avv xid:(NSString *)xid secure3dTransactionId:(NSString *)secure3dTransactionId cardVerification:(NSString *)cardVerification orderId:(NSString *)orderId amount:(NSString *)amount __attribute__((swift_name("init(note:token:method:cardholderName:customName:eci:avv:xid:secure3dTransactionId:cardVerification:orderId:amount:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property NSString *amount __attribute__((swift_name("amount")));
@property NSString *avv __attribute__((swift_name("avv")));
@property NSString *cardVerification __attribute__((swift_name("cardVerification")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *currency __attribute__((swift_name("currency")));
@property NSString *customName __attribute__((swift_name("customName")));
@property NSString *cvc __attribute__((swift_name("cvc")));
@property NSString *eci __attribute__((swift_name("eci")));
@property NSString *expDate __attribute__((swift_name("expDate")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *note __attribute__((swift_name("note")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@property NSString *pan __attribute__((swift_name("pan")));
@property NSString *secure3dTransactionId __attribute__((swift_name("secure3dTransactionId")));
@property NSString *token __attribute__((swift_name("token")));
@property NSString *xid __attribute__((swift_name("xid")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGStoredCardUpdate.Companion")))
@interface IPGSCIPGStoredCardUpdateCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGTransactionStatusModel")))
@interface IPGSCIPGTransactionStatusModel : IPGSCBaseRequestModel
- (instancetype)initWithOrderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("init(orderId:method:cardholderName:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (IPGSCIPGTransactionStatusModel *)doCopyOrderId:(NSString *)orderId method:(NSString *)method cardholderName:(NSString *)cardholderName __attribute__((swift_name("doCopy(orderId:method:cardholderName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *cardholderName __attribute__((swift_name("cardholderName")));
@property NSString *method __attribute__((swift_name("method")));
@property NSString *orderId __attribute__((swift_name("orderId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IPGTransactionStatusModel.Companion")))
@interface IPGSCIPGTransactionStatusModelCompanion : IPGSCBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverFactoryKt")))
@interface IPGSCDatabaseDriverFactoryKt : IPGSCBase
+ (id<IPGSCIPGDatabase>)createDatabaseDriverFactory:(IPGSCDatabaseDriverFactory *)driverFactory __attribute__((swift_name("createDatabase(driverFactory:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ModuleDIKt")))
@interface IPGSCModuleDIKt : IPGSCBase
+ (IPGSCKodein_diDIModule *)sharedModule __attribute__((swift_name("sharedModule()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BaseExtKt")))
@interface IPGSCBaseExtKt : IPGSCBase
+ (NSString *)asFormData:(id)receiver ICNativeConnector:(id<IPGSCICNativeConnector>)ICNativeConnector __attribute__((swift_name("asFormData(_:ICNativeConnector:)")));
+ (id<IPGSCKtor_httpParameters>)asParameters:(id)receiver ICNativeConnector:(id<IPGSCICNativeConnector> _Nullable)ICNativeConnector __attribute__((swift_name("asParameters(_:ICNativeConnector:)")));
+ (NSString *)asUrlEncodedParameters:(id)receiver ICNativeConnector:(id<IPGSCICNativeConnector> _Nullable)ICNativeConnector __attribute__((swift_name("asUrlEncodedParameters(_:ICNativeConnector:)")));
+ (IPGSCAcqSchemeEnum * _Nullable)checkCardNumberType:(NSString *)receiver __attribute__((swift_name("checkCardNumberType(_:)")));
+ (NSString *)encodeUrlUtf8:(NSString *)receiver __attribute__((swift_name("encodeUrlUtf8(_:)")));
+ (double)roundToDecimals:(double)receiver decimals:(int32_t)decimals __attribute__((swift_name("roundToDecimals(_:decimals:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CommonUtilsKt")))
@interface IPGSCCommonUtilsKt : IPGSCBase
+ (NSString *)urlEncodeUtf8:(NSString *)receiver __attribute__((swift_name("urlEncodeUtf8(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppDispatcherKt")))
@interface IPGSCAppDispatcherKt : IPGSCBase
@property (class, readonly) id<IPGSCKotlinCoroutineContext> backgroundDispatcher __attribute__((swift_name("backgroundDispatcher")));
@property (class, readonly) id<IPGSCKotlinCoroutineContext> uiDispatcher __attribute__((swift_name("uiDispatcher")));
@end;

__attribute__((swift_name("RuntimeCloseable")))
@protocol IPGSCRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol IPGSCRuntimeSqlDriver <IPGSCRuntimeCloseable>
@required
- (IPGSCRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (void)executeIdentifier:(IPGSCInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<IPGSCRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<IPGSCRuntimeSqlCursor>)executeQueryIdentifier:(IPGSCInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<IPGSCRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:parameters:binders:)")));
- (IPGSCRuntimeTransacterTransaction *)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
@end;

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol IPGSCKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface IPGSCKtor_client_coreHttpClient : IPGSCBase <IPGSCKotlinx_coroutines_coreCoroutineScope, IPGSCKtor_ioCloseable>
- (instancetype)initWithEngine:(id<IPGSCKtor_client_coreHttpClientEngine>)engine userConfig:(IPGSCKtor_client_coreHttpClientConfig *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (IPGSCKtor_client_coreHttpClient *)configBlock:(void (^)(IPGSCKtor_client_coreHttpClientConfig *))block __attribute__((swift_name("config(block:)")));
- (BOOL)isSupportedCapability:(id<IPGSCKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<IPGSCKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) IPGSCKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher"))) __attribute__((unavailable("[dispatcher] is deprecated. Use coroutineContext instead.")));
@property (readonly) id<IPGSCKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) IPGSCKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) IPGSCKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) IPGSCKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) IPGSCKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) IPGSCKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end;

__attribute__((swift_name("Kodein_diDIAware")))
@protocol IPGSCKodein_diDIAware
@required
@property (readonly) id<IPGSCKodein_diDI> di __attribute__((swift_name("di")));
@property (readonly) id<IPGSCKodein_diDIContext> diContext __attribute__((swift_name("diContext")));
@property (readonly) IPGSCKodein_diDITrigger * _Nullable diTrigger __attribute__((swift_name("diTrigger")));
@property (readonly) id<IPGSCKodein_diDI> kodein __attribute__((swift_name("kodein"))) __attribute__((unavailable("!!! THIS HAS BEEN REMOVED FROM 7.0 !!! As soon as you are using _Kodein-DI 7.x_, the old API named _Kodein_ API is broken. we highly recommend that you take some time to move from it to the new API with _DI_ named objects.")));
@property (readonly) id<IPGSCKodein_diDIContext> kodeinContext __attribute__((swift_name("kodeinContext"))) __attribute__((unavailable("!!! THIS HAS BEEN REMOVED FROM 7.0 !!! As soon as you are using _Kodein-DI 7.x_, the old API named _Kodein_ API is broken. we highly recommend that you take some time to move from it to the new API with _DI_ named objects.")));
@property (readonly) IPGSCKodein_diDITrigger * _Nullable kodeinTrigger __attribute__((swift_name("kodeinTrigger"))) __attribute__((unavailable("!!! THIS HAS BEEN REMOVED FROM 7.0 !!! As soon as you are using _Kodein-DI 7.x_, the old API named _Kodein_ API is broken. we highly recommend that you take some time to move from it to the new API with _DI_ named objects.")));
@end;

__attribute__((swift_name("Kodein_diDI")))
@protocol IPGSCKodein_diDI <IPGSCKodein_diDIAware>
@required
@property (readonly) id<IPGSCKodein_diDIContainer> container __attribute__((swift_name("container")));
@end;

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol IPGSCKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<IPGSCKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_httpParameters")))
@protocol IPGSCKtor_httpParameters <IPGSCKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialFormat")))
@protocol IPGSCKotlinx_serialization_runtimeSerialFormat
@required
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeStringFormat")))
@protocol IPGSCKotlinx_serialization_runtimeStringFormat <IPGSCKotlinx_serialization_runtimeSerialFormat>
@required
- (id _Nullable)parseDeserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("parse(deserializer:string:)")));
- (NSString *)stringifySerializer:(id<IPGSCKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("stringify(serializer:value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeJson")))
@interface IPGSCKotlinx_serialization_runtimeJson : IPGSCBase <IPGSCKotlinx_serialization_runtimeStringFormat>
- (instancetype)initWithBlock:(void (^)(IPGSCKotlinx_serialization_runtimeJsonBuilder *))block __attribute__((swift_name("init(block:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable("Default constructor is deprecated, please specify the desired configuration explicitly or use Json(JsonConfiguration.Default)")));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithConfiguration:(IPGSCKotlinx_serialization_runtimeJsonConfiguration *)configuration context:(id<IPGSCKotlinx_serialization_runtimeSerialModule>)context __attribute__((swift_name("init(configuration:context:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)fromJsonDeserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer json:(IPGSCKotlinx_serialization_runtimeJsonElement *)json __attribute__((swift_name("fromJson(deserializer:json:)")));
- (id)fromJsonTree:(IPGSCKotlinx_serialization_runtimeJsonElement *)tree __attribute__((swift_name("fromJson(tree:)")));
- (id _Nullable)parseDeserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("parse(deserializer:string:)")));
- (IPGSCKotlinx_serialization_runtimeJsonElement *)parseJsonString:(NSString *)string __attribute__((swift_name("parseJson(string:)")));
- (NSString *)stringifySerializer:(id<IPGSCKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("stringify(serializer:value:)")));
- (IPGSCKotlinx_serialization_runtimeJsonElement *)toJsonValue:(id)value __attribute__((swift_name("toJson(value:)")));
- (IPGSCKotlinx_serialization_runtimeJsonElement *)toJsonSerializer:(id<IPGSCKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("toJson(serializer:value:)")));
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface IPGSCRuntimeTransacterTransaction : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
- (void)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(IPGSCRuntimeTransacterTransaction *))body __attribute__((swift_name("transaction(body:)")));
@property (readonly) IPGSCRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end;

__attribute__((swift_name("RuntimeSqlDriverSchema")))
@protocol IPGSCRuntimeSqlDriverSchema
@required
- (void)createDriver:(id<IPGSCRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (void)migrateDriver:(id<IPGSCRuntimeSqlDriver>)driver oldVersion:(int32_t)oldVersion newVersion:(int32_t)newVersion __attribute__((swift_name("migrate(driver:oldVersion:newVersion:)")));
@property (readonly) int32_t version __attribute__((swift_name("version")));
@end;

__attribute__((swift_name("RuntimeQuery")))
@interface IPGSCRuntimeQuery : IPGSCBase
- (instancetype)initWithQueries:(NSMutableArray<IPGSCRuntimeQuery *> *)queries mapper:(id (^)(id<IPGSCRuntimeSqlCursor>))mapper __attribute__((swift_name("init(queries:mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<IPGSCRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (id<IPGSCRuntimeSqlCursor>)execute __attribute__((swift_name("execute()")));
- (NSArray<id> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (id)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (id _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
- (void)notifyDataChanged __attribute__((swift_name("notifyDataChanged()")));
- (void)removeListenerListener:(id<IPGSCRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@property (readonly) id (^mapper)(id<IPGSCRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end;

__attribute__((swift_name("KotlinCoroutineContext")))
@protocol IPGSCKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<IPGSCKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<IPGSCKotlinCoroutineContextElement> _Nullable)getKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<IPGSCKotlinCoroutineContext>)minusKeyKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<IPGSCKotlinCoroutineContext>)plusContext:(id<IPGSCKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface IPGSCKotlinThrowable : IPGSCBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(IPGSCKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (IPGSCKotlinArray *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerializationStrategy")))
@protocol IPGSCKotlinx_serialization_runtimeSerializationStrategy
@required
- (void)serializeEncoder:(id<IPGSCKotlinx_serialization_runtimeEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDeserializationStrategy")))
@protocol IPGSCKotlinx_serialization_runtimeDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<IPGSCKotlinx_serialization_runtimeDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (id _Nullable)patchDecoder:(id<IPGSCKotlinx_serialization_runtimeDecoder>)decoder old:(id _Nullable)old __attribute__((swift_name("patch(decoder:old:)")));
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeKSerializer")))
@protocol IPGSCKotlinx_serialization_runtimeKSerializer <IPGSCKotlinx_serialization_runtimeSerializationStrategy, IPGSCKotlinx_serialization_runtimeDeserializationStrategy>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface IPGSCKotlinNothing : IPGSCBase
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIModule")))
@interface IPGSCKodein_diDIModule : IPGSCBase
- (instancetype)initWithAllowSilentOverride:(BOOL)allowSilentOverride init:(void (^)(id<IPGSCKodein_diDIBuilder>))init __attribute__((swift_name("init(allowSilentOverride:init:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("You should name your modules, for debug purposes.")));
- (instancetype)initWithName:(NSString *)name allowSilentOverride:(BOOL)allowSilentOverride prefix:(NSString *)prefix init:(void (^)(id<IPGSCKodein_diDIBuilder>))init __attribute__((swift_name("init(name:allowSilentOverride:prefix:init:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (BOOL)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (void (^)(id<IPGSCKodein_diDIBuilder>))component4 __attribute__((swift_name("component4()")));
- (IPGSCKodein_diDIModule *)doCopyName:(NSString *)name allowSilentOverride:(BOOL)allowSilentOverride prefix:(NSString *)prefix init:(void (^)(id<IPGSCKodein_diDIBuilder>))init __attribute__((swift_name("doCopy(name:allowSilentOverride:prefix:init:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSilentOverride __attribute__((swift_name("allowSilentOverride")));
@property (readonly, getter=doInit) void (^init)(id<IPGSCKodein_diDIBuilder>) __attribute__((swift_name("init")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *prefix __attribute__((swift_name("prefix")));
@end;

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol IPGSCRuntimeSqlPreparedStatement
@required
- (void)bindBytesIndex:(int32_t)index value:(IPGSCKotlinByteArray * _Nullable)value __attribute__((swift_name("bindBytes(index:value:)")));
- (void)bindDoubleIndex:(int32_t)index value:(IPGSCDouble * _Nullable)value __attribute__((swift_name("bindDouble(index:value:)")));
- (void)bindLongIndex:(int32_t)index value:(IPGSCLong * _Nullable)value __attribute__((swift_name("bindLong(index:value:)")));
- (void)bindStringIndex:(int32_t)index value:(NSString * _Nullable)value __attribute__((swift_name("bindString(index:value:)")));
@end;

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol IPGSCRuntimeSqlCursor <IPGSCRuntimeCloseable>
@required
- (IPGSCKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (IPGSCDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (IPGSCLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (BOOL)next __attribute__((swift_name("next()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol IPGSCKtor_client_coreHttpClientEngine <IPGSCKotlinx_coroutines_coreCoroutineScope, IPGSCKtor_ioCloseable>
@required
- (void)installClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) IPGSCKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) IPGSCKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<IPGSCKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface IPGSCKtor_client_coreHttpClientConfig : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (IPGSCKtor_client_coreHttpClientConfig *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(IPGSCKtor_client_coreHttpClientEngineConfig *))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(IPGSCKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installFeature:(id<IPGSCKtor_client_coreHttpClientFeature>)feature configure:(void (^)(id))configure __attribute__((swift_name("install(feature:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(IPGSCKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(IPGSCKtor_client_coreHttpClientConfig *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol IPGSCKtor_client_coreHttpClientEngineCapability
@required
@end;

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol IPGSCKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(IPGSCKtor_utilsAttributeKey *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(IPGSCKtor_utilsAttributeKey *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(IPGSCKtor_utilsAttributeKey *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(IPGSCKtor_utilsAttributeKey *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(IPGSCKtor_utilsAttributeKey *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(IPGSCKtor_utilsAttributeKey *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(IPGSCKtor_utilsAttributeKey *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(IPGSCKtor_utilsAttributeKey *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<IPGSCKtor_utilsAttributeKey *> *allKeys __attribute__((swift_name("allKeys")));
@end;

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol IPGSCKotlinCoroutineContextElement <IPGSCKotlinCoroutineContext>
@required
@property (readonly) id<IPGSCKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface IPGSCKotlinAbstractCoroutineContextElement : IPGSCBase <IPGSCKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<IPGSCKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol IPGSCKotlinContinuationInterceptor <IPGSCKotlinCoroutineContextElement>
@required
- (id<IPGSCKotlinContinuation>)interceptContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface IPGSCKotlinx_coroutines_coreCoroutineDispatcher : IPGSCKotlinAbstractCoroutineContextElement <IPGSCKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<IPGSCKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)dispatchContext:(id<IPGSCKotlinCoroutineContext>)context block:(id<IPGSCKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<IPGSCKotlinCoroutineContext>)context block:(id<IPGSCKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<IPGSCKotlinContinuation>)interceptContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<IPGSCKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (IPGSCKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(IPGSCKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<IPGSCKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface IPGSCKtor_client_coreHttpClientEngineConfig : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property IPGSCKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property (readonly) IPGSCKotlinNothing *response __attribute__((swift_name("response"))) __attribute__((unavailable("Response config is deprecated. See [HttpPlainText] feature for charset configuration")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end;

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface IPGSCKtor_utilsPipeline : IPGSCBase
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(IPGSCKotlinArray *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(IPGSCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));
- (void)insertPhaseAfterReference:(IPGSCKtor_utilsPipelinePhase *)reference phase:(IPGSCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(IPGSCKtor_utilsPipelinePhase *)reference phase:(IPGSCKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(IPGSCKtor_utilsPipelinePhase *)phase block:(id<IPGSCKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (void)mergeFrom:(IPGSCKtor_utilsPipeline *)from __attribute__((swift_name("merge(from:)")));
@property (readonly) id<IPGSCKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<IPGSCKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface IPGSCKtor_client_coreHttpReceivePipeline : IPGSCKtor_utilsPipeline
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface IPGSCKtor_client_coreHttpRequestPipeline : IPGSCKtor_utilsPipeline
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface IPGSCKtor_client_coreHttpResponsePipeline : IPGSCKtor_utilsPipeline
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface IPGSCKtor_client_coreHttpSendPipeline : IPGSCKtor_utilsPipeline
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithPhase:(IPGSCKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<IPGSCKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(IPGSCKotlinArray *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end;

__attribute__((swift_name("Kodein_diDIContainer")))
@protocol IPGSCKodein_diDIContainer
@required
- (NSArray<id (^)(id _Nullable)> *)allFactoriesKey:(IPGSCKodein_diDIKey *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("allFactories(key:context:overrideLevel:)")));
- (NSArray<id (^)(void)> *)allProvidersKey:(IPGSCKodein_diDIKey *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("allProviders(key:context:overrideLevel:)")));
- (id (^)(id _Nullable))factoryKey:(IPGSCKodein_diDIKey *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("factory(key:context:overrideLevel:)")));
- (id (^ _Nullable)(id _Nullable))factoryOrNullKey:(IPGSCKodein_diDIKey *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("factoryOrNull(key:context:overrideLevel:)")));
- (id (^)(void))providerKey:(IPGSCKodein_diDIKey *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("provider(key:context:overrideLevel:)")));
- (id (^ _Nullable)(void))providerOrNullKey:(IPGSCKodein_diDIKey *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("providerOrNull(key:context:overrideLevel:)")));
@property (readonly) id<IPGSCKodein_diDITree> tree __attribute__((swift_name("tree")));
@end;

__attribute__((swift_name("Kodein_diDIContext")))
@protocol IPGSCKodein_diDIContext
@required
@property (readonly) IPGSCKodein_typeTypeToken *type __attribute__((swift_name("type")));
@property (readonly) id value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDITrigger")))
@interface IPGSCKodein_diDITrigger : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)trigger __attribute__((swift_name("trigger()")));
@property (readonly) NSMutableArray<id<IPGSCKotlinLazy>> *properties __attribute__((swift_name("properties")));
@end;

__attribute__((swift_name("KotlinMapEntry")))
@protocol IPGSCKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModule")))
@protocol IPGSCKotlinx_serialization_runtimeSerialModule
@required
- (void)dumpToCollector:(id<IPGSCKotlinx_serialization_runtimeSerialModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer> _Nullable)getContextualKclass:(id<IPGSCKotlinKClass>)kclass __attribute__((swift_name("getContextual(kclass:)")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<IPGSCKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<IPGSCKotlinx_serialization_runtimeKSerializer> _Nullable)getPolymorphicBaseClass:(id<IPGSCKotlinKClass>)baseClass serializedClassName:(NSString *)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeJsonBuilder")))
@interface IPGSCKotlinx_serialization_runtimeJsonBuilder : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (IPGSCKotlinx_serialization_runtimeJsonConfiguration *)buildConfiguration __attribute__((swift_name("buildConfiguration()")));
- (id<IPGSCKotlinx_serialization_runtimeSerialModule>)buildModule __attribute__((swift_name("buildModule()")));
@property BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));
@property NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));
@property BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property NSString *indent __attribute__((swift_name("indent")));
@property BOOL isLenient __attribute__((swift_name("isLenient")));
@property BOOL prettyPrint __attribute__((swift_name("prettyPrint")));
@property id<IPGSCKotlinx_serialization_runtimeSerialModule> serialModule __attribute__((swift_name("serialModule")));
@property BOOL serializeSpecialFloatingPointValues __attribute__((swift_name("serializeSpecialFloatingPointValues")));
@property BOOL strictMode __attribute__((swift_name("strictMode"))) __attribute__((unavailable("'strictMode = true' is replaced with 3 new configuration parameters: 'ignoreUnknownKeys = false' to fail if an unknown key is encountered, 'serializeSpecialFloatingPointValues = false' to fail on 'NaN' and 'Infinity' values, 'isLenient = false' to prohibit parsing of any non-compliant or malformed JSON")));
@property BOOL unquoted __attribute__((swift_name("unquoted"))) __attribute__((unavailable("'unquoted' is deprecated in the favour of 'unquotedPrint'")));
@property BOOL unquotedPrint __attribute__((swift_name("unquotedPrint")));
@property BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeJsonConfiguration")))
@interface IPGSCKotlinx_serialization_runtimeJsonConfiguration : IPGSCBase
- (instancetype)initWithEncodeDefaults:(BOOL)encodeDefaults ignoreUnknownKeys:(BOOL)ignoreUnknownKeys isLenient:(BOOL)isLenient serializeSpecialFloatingPointValues:(BOOL)serializeSpecialFloatingPointValues allowStructuredMapKeys:(BOOL)allowStructuredMapKeys prettyPrint:(BOOL)prettyPrint unquotedPrint:(BOOL)unquotedPrint indent:(NSString *)indent useArrayPolymorphism:(BOOL)useArrayPolymorphism classDiscriminator:(NSString *)classDiscriminator updateMode:(IPGSCKotlinx_serialization_runtimeUpdateMode *)updateMode __attribute__((swift_name("init(encodeDefaults:ignoreUnknownKeys:isLenient:serializeSpecialFloatingPointValues:allowStructuredMapKeys:prettyPrint:unquotedPrint:indent:useArrayPolymorphism:classDiscriminator:updateMode:)"))) __attribute__((objc_designated_initializer));
- (IPGSCKotlinx_serialization_runtimeJsonConfiguration *)doCopyEncodeDefaults:(BOOL)encodeDefaults ignoreUnknownKeys:(BOOL)ignoreUnknownKeys isLenient:(BOOL)isLenient serializeSpecialFloatingPointValues:(BOOL)serializeSpecialFloatingPointValues allowStructuredMapKeys:(BOOL)allowStructuredMapKeys prettyPrint:(BOOL)prettyPrint unquotedPrint:(BOOL)unquotedPrint indent:(NSString *)indent useArrayPolymorphism:(BOOL)useArrayPolymorphism classDiscriminator:(NSString *)classDiscriminator updateMode:(IPGSCKotlinx_serialization_runtimeUpdateMode *)updateMode __attribute__((swift_name("doCopy(encodeDefaults:ignoreUnknownKeys:isLenient:serializeSpecialFloatingPointValues:allowStructuredMapKeys:prettyPrint:unquotedPrint:indent:useArrayPolymorphism:classDiscriminator:updateMode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeJsonElement")))
@interface IPGSCKotlinx_serialization_runtimeJsonElement : IPGSCBase
- (BOOL)containsKey_:(NSString *)key __attribute__((swift_name("contains(key_:)")));
@property (readonly) BOOL isNull __attribute__((swift_name("isNull")));
@property (readonly) NSArray<IPGSCKotlinx_serialization_runtimeJsonElement *> *jsonArray __attribute__((swift_name("jsonArray")));
@property (readonly) IPGSCKotlinx_serialization_runtimeJsonNull *jsonNull __attribute__((swift_name("jsonNull")));
@property (readonly) NSDictionary<NSString *, IPGSCKotlinx_serialization_runtimeJsonElement *> *jsonObject __attribute__((swift_name("jsonObject")));
@property (readonly) IPGSCKotlinx_serialization_runtimeJsonPrimitive *primitive __attribute__((swift_name("primitive")));
@end;

__attribute__((swift_name("RuntimeQueryListener")))
@protocol IPGSCRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end;

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol IPGSCKotlinCoroutineContextKey
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface IPGSCKotlinArray : IPGSCBase
+ (instancetype)arrayWithSize:(int32_t)size init:(id _Nullable (^)(IPGSCInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (id _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<IPGSCKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(id _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeEncoder")))
@protocol IPGSCKotlinx_serialization_runtimeEncoder
@required
- (id<IPGSCKotlinx_serialization_runtimeCompositeEncoder>)beginCollectionDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize typeSerializers:(IPGSCKotlinArray *)typeSerializers __attribute__((swift_name("beginCollection(descriptor:collectionSize:typeSerializers:)")));
- (id<IPGSCKotlinx_serialization_runtimeCompositeEncoder>)beginStructureDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeSerializers:(IPGSCKotlinArray *)typeSerializers __attribute__((swift_name("beginStructure(descriptor:typeSerializers:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<IPGSCKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<IPGSCKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
- (void)encodeUnit __attribute__((swift_name("encodeUnit()")));
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialDescriptor")))
@protocol IPGSCKotlinx_serialization_runtimeSerialDescriptor
@required
- (NSArray<id<IPGSCKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (NSArray<id<IPGSCKotlinAnnotation>> *)getEntityAnnotations __attribute__((swift_name("getEntityAnnotations()"))) __attribute__((deprecated("Deprecated in the favour of 'annotations' property")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<IPGSCKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) IPGSCKotlinx_serialization_runtimeSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *name __attribute__((swift_name("name"))) __attribute__((unavailable("name property deprecated in the favour of serialName")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeDecoder")))
@protocol IPGSCKotlinx_serialization_runtimeDecoder
@required
- (id<IPGSCKotlinx_serialization_runtimeCompositeDecoder>)beginStructureDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor typeParams:(IPGSCKotlinArray *)typeParams __attribute__((swift_name("beginStructure(descriptor:typeParams:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (IPGSCKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
- (void)decodeUnit __attribute__((swift_name("decodeUnit()")));
- (id _Nullable)updateNullableSerializableValueDeserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableValue(deserializer:old:)")));
- (id _Nullable)updateSerializableValueDeserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableValue(deserializer:old:)")));
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) IPGSCKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((swift_name("Kodein_diDIBindBuilder")))
@protocol IPGSCKodein_diDIBindBuilder
@required
@property (readonly) IPGSCKodein_typeTypeToken *contextType __attribute__((swift_name("contextType")));
@end;

__attribute__((swift_name("Kodein_diDIBindBuilderWithContext")))
@protocol IPGSCKodein_diDIBindBuilderWithContext <IPGSCKodein_diDIBindBuilder>
@required
@end;

__attribute__((swift_name("Kodein_diDIBindBuilderWithScope")))
@protocol IPGSCKodein_diDIBindBuilderWithScope <IPGSCKodein_diDIBindBuilder>
@required
@property (readonly) id<IPGSCKodein_diScope> scope __attribute__((swift_name("scope")));
@end;

__attribute__((swift_name("Kodein_diDIBuilder")))
@protocol IPGSCKodein_diDIBuilder <IPGSCKodein_diDIBindBuilderWithContext, IPGSCKodein_diDIBindBuilderWithScope>
@required
- (id<IPGSCKodein_diDIBuilderDirectBinder>)BindTag:(id _Nullable)tag overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("Bind(tag:overrides:)")));
- (id<IPGSCKodein_diDIBuilderTypeBinder>)BindType:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("Bind(type:tag:overrides:)")));
- (void)RegisterContextTranslatorTranslator:(id<IPGSCKodein_diContextTranslator>)translator __attribute__((swift_name("RegisterContextTranslator(translator:)")));
- (id<IPGSCKodein_diDIBuilderConstantBinder>)constantTag:(id)tag overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("constant(tag:overrides:)")));
- (void)importModule:(IPGSCKodein_diDIModule *)module allowOverride:(BOOL)allowOverride __attribute__((swift_name("import(module:allowOverride:)")));
- (void)importAllModules:(IPGSCKotlinArray *)modules allowOverride:(BOOL)allowOverride __attribute__((swift_name("importAll(modules:allowOverride:)")));
- (void)importAllModules:(id)modules allowOverride_:(BOOL)allowOverride __attribute__((swift_name("importAll(modules:allowOverride_:)")));
- (void)importOnceModule:(IPGSCKodein_diDIModule *)module allowOverride:(BOOL)allowOverride __attribute__((swift_name("importOnce(module:allowOverride:)")));
- (void)onReadyCb:(void (^)(id<IPGSCKodein_diDirectDI>))cb __attribute__((swift_name("onReady(cb:)")));
@property (readonly) id<IPGSCKodein_diDIContainerBuilder> containerBuilder __attribute__((swift_name("containerBuilder")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface IPGSCKotlinByteArray : IPGSCBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(IPGSCByte *(^)(IPGSCInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (IPGSCKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientFeature")))
@protocol IPGSCKtor_client_coreHttpClientFeature
@required
- (void)installFeature:(id)feature scope:(IPGSCKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(feature:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) IPGSCKtor_utilsAttributeKey *key __attribute__((swift_name("key")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface IPGSCKtor_utilsAttributeKey : IPGSCBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinContinuation")))
@protocol IPGSCKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<IPGSCKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol IPGSCKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface IPGSCKtor_client_coreProxyConfig : IPGSCBase
- (instancetype)initWithUrl:(IPGSCKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface IPGSCKtor_utilsPipelinePhase : IPGSCBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinFunction")))
@protocol IPGSCKotlinFunction
@required
@end;

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol IPGSCKotlinSuspendFunction2 <IPGSCKotlinFunction>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIKey")))
@interface IPGSCKodein_diDIKey : IPGSCBase
- (instancetype)initWithContextType:(IPGSCKodein_typeTypeToken *)contextType argType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("init(contextType:argType:type:tag:)"))) __attribute__((objc_designated_initializer));
- (IPGSCKodein_typeTypeToken *)component1 __attribute__((swift_name("component1()")));
- (IPGSCKodein_typeTypeToken *)component2 __attribute__((swift_name("component2()")));
- (IPGSCKodein_typeTypeToken *)component3 __attribute__((swift_name("component3()")));
- (id _Nullable)component4 __attribute__((swift_name("component4()")));
- (IPGSCKodein_diDIKey *)doCopyContextType:(IPGSCKodein_typeTypeToken *)contextType argType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("doCopy(contextType:argType:type:tag:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) IPGSCKodein_typeTypeToken *argType __attribute__((swift_name("argType")));
@property (readonly) NSString *bindDescription __attribute__((swift_name("bindDescription")));
@property (readonly) NSString *bindFullDescription __attribute__((swift_name("bindFullDescription")));
@property (readonly) IPGSCKodein_typeTypeToken *contextType __attribute__((swift_name("contextType")));
@property (readonly, getter=description_) NSString *description __attribute__((swift_name("description")));
@property (readonly) NSString *fullDescription __attribute__((swift_name("fullDescription")));
@property (readonly) NSString *internalDescription __attribute__((swift_name("internalDescription")));
@property (readonly) id _Nullable tag __attribute__((swift_name("tag")));
@property (readonly) IPGSCKodein_typeTypeToken *type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("Kodein_diDITree")))
@protocol IPGSCKodein_diDITree
@required
- (NSArray<IPGSCKotlinTriple *> *)findKey:(IPGSCKodein_diDIKey *)key overrideLevel:(int32_t)overrideLevel all:(BOOL)all __attribute__((swift_name("find(key:overrideLevel:all:)")));
- (NSArray<IPGSCKotlinTriple *> *)findSearch:(IPGSCKodein_diSearchSpecs *)search __attribute__((swift_name("find(search:)")));
- (IPGSCKotlinTriple * _Nullable)getKey__:(IPGSCKodein_diDIKey *)key __attribute__((swift_name("get(key__:)")));
@property (readonly) NSDictionary<IPGSCKodein_diDIKey *, NSArray<IPGSCKodein_diDIDefinition *> *> *bindings __attribute__((swift_name("bindings")));
@property (readonly) NSArray<id<IPGSCKodein_diExternalSource>> *externalSources __attribute__((swift_name("externalSources")));
@property (readonly) NSArray<id<IPGSCKodein_diContextTranslator>> *registeredTranslators __attribute__((swift_name("registeredTranslators")));
@end;

__attribute__((swift_name("Kodein_typeTypeToken")))
@interface IPGSCKodein_typeTypeToken : IPGSCBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (IPGSCKotlinArray *)getGenericParameters __attribute__((swift_name("getGenericParameters()")));
- (IPGSCKodein_typeTypeToken * _Nullable)getRaw __attribute__((swift_name("getRaw()")));
- (NSArray<IPGSCKodein_typeTypeToken *> *)getSuper __attribute__((swift_name("getSuper()")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isAssignableFromTypeToken:(IPGSCKodein_typeTypeToken *)typeToken __attribute__((swift_name("isAssignableFrom(typeToken:)")));
- (BOOL)isGeneric __attribute__((swift_name("isGeneric()")));
- (BOOL)isWildcard __attribute__((swift_name("isWildcard()")));
- (NSString *)qualifiedDispString __attribute__((swift_name("qualifiedDispString()")));
- (NSString *)qualifiedErasedDispString __attribute__((swift_name("qualifiedErasedDispString()")));
- (NSString *)simpleDispString __attribute__((swift_name("simpleDispString()")));
- (NSString *)simpleErasedDispString __attribute__((swift_name("simpleErasedDispString()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("KotlinLazy")))
@protocol IPGSCKotlinLazy
@required
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialModuleCollector")))
@protocol IPGSCKotlinx_serialization_runtimeSerialModuleCollector
@required
- (void)contextualKClass:(id<IPGSCKotlinKClass>)kClass serializer:(id<IPGSCKotlinx_serialization_runtimeKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<IPGSCKotlinKClass>)baseClass actualClass:(id<IPGSCKotlinKClass>)actualClass actualSerializer:(id<IPGSCKotlinx_serialization_runtimeKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol IPGSCKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol IPGSCKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol IPGSCKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol IPGSCKotlinKClass <IPGSCKotlinKDeclarationContainer, IPGSCKotlinKAnnotatedElement, IPGSCKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeUpdateMode")))
@interface IPGSCKotlinx_serialization_runtimeUpdateMode : IPGSCKotlinEnum
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) IPGSCKotlinx_serialization_runtimeUpdateMode *banned __attribute__((swift_name("banned")));
@property (class, readonly) IPGSCKotlinx_serialization_runtimeUpdateMode *overwrite __attribute__((swift_name("overwrite")));
@property (class, readonly) IPGSCKotlinx_serialization_runtimeUpdateMode *update __attribute__((swift_name("update")));
- (int32_t)compareToOther:(IPGSCKotlinx_serialization_runtimeUpdateMode *)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeJsonPrimitive")))
@interface IPGSCKotlinx_serialization_runtimeJsonPrimitive : IPGSCKotlinx_serialization_runtimeJsonElement
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL boolean __attribute__((swift_name("boolean")));
@property (readonly) IPGSCBoolean * _Nullable booleanOrNull __attribute__((swift_name("booleanOrNull")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSString * _Nullable contentOrNull __attribute__((swift_name("contentOrNull")));
@property (readonly, getter=double) double double_ __attribute__((swift_name("double_")));
@property (readonly) IPGSCDouble * _Nullable doubleOrNull __attribute__((swift_name("doubleOrNull")));
@property (readonly, getter=float) float float_ __attribute__((swift_name("float_")));
@property (readonly) IPGSCFloat * _Nullable floatOrNull __attribute__((swift_name("floatOrNull")));
@property (readonly, getter=int) int32_t int_ __attribute__((swift_name("int_")));
@property (readonly) IPGSCInt * _Nullable intOrNull __attribute__((swift_name("intOrNull")));
@property (readonly, getter=long) int64_t long_ __attribute__((swift_name("long_")));
@property (readonly) IPGSCLong * _Nullable longOrNull __attribute__((swift_name("longOrNull")));
@property (readonly) IPGSCKotlinx_serialization_runtimeJsonPrimitive *primitive __attribute__((swift_name("primitive")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_runtimeJsonNull")))
@interface IPGSCKotlinx_serialization_runtimeJsonNull : IPGSCKotlinx_serialization_runtimeJsonPrimitive
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)jsonNull __attribute__((swift_name("init()")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSString * _Nullable contentOrNull __attribute__((swift_name("contentOrNull")));
@property (readonly) IPGSCKotlinx_serialization_runtimeJsonNull *jsonNull __attribute__((swift_name("jsonNull")));
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol IPGSCKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next_ __attribute__((swift_name("next_()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeEncoder")))
@protocol IPGSCKotlinx_serialization_runtimeCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (void)encodeIntElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));
- (void)encodeNonSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(id)value __attribute__((swift_name("encodeNonSerializableElement(descriptor:index:value:)"))) __attribute__((unavailable("This method is deprecated for removal. Please remove it from your implementation and delegate to default method instead")));
- (void)encodeNullableSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<IPGSCKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<IPGSCKotlinx_serialization_runtimeSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)encodeUnitElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol IPGSCKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeSerialKind")))
@interface IPGSCKotlinx_serialization_runtimeSerialKind : IPGSCBase
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_runtimeCompositeDecoder")))
@protocol IPGSCKotlinx_serialization_runtimeCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:)")));
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:)")));
- (int16_t)decodeShortElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)decodeUnitElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeUnitElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (id _Nullable)updateNullableSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateNullableSerializableElement(descriptor:index:deserializer:old:)")));
- (id _Nullable)updateSerializableElementDescriptor:(id<IPGSCKotlinx_serialization_runtimeSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<IPGSCKotlinx_serialization_runtimeDeserializationStrategy>)deserializer old:(id _Nullable)old __attribute__((swift_name("updateSerializableElement(descriptor:index:deserializer:old:)")));
@property (readonly) id<IPGSCKotlinx_serialization_runtimeSerialModule> context __attribute__((swift_name("context")));
@property (readonly) IPGSCKotlinx_serialization_runtimeUpdateMode *updateMode __attribute__((swift_name("updateMode")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderDirectBinder")))
@protocol IPGSCKodein_diDIBuilderDirectBinder
@required
- (void)fromBinding:(id<IPGSCKodein_diDIBinding>)binding __attribute__((swift_name("from(binding:)")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderTypeBinder")))
@protocol IPGSCKodein_diDIBuilderTypeBinder
@required
- (void)withBinding:(id<IPGSCKodein_diDIBinding>)binding __attribute__((swift_name("with(binding:)")));
@end;

__attribute__((swift_name("Kodein_diContextTranslator")))
@protocol IPGSCKodein_diContextTranslator
@required
- (id)translateCtx:(id)ctx __attribute__((swift_name("translate(ctx:)")));
@property (readonly) IPGSCKodein_typeTypeToken *contextType __attribute__((swift_name("contextType")));
@property (readonly) IPGSCKodein_typeTypeToken *scopeType __attribute__((swift_name("scopeType")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderConstantBinder")))
@protocol IPGSCKodein_diDIBuilderConstantBinder
@required
- (void)WithValueType:(IPGSCKodein_typeTypeToken *)valueType value:(id)value __attribute__((swift_name("With(valueType:value:)")));
@end;

__attribute__((swift_name("Kodein_diDirectDIAware")))
@protocol IPGSCKodein_diDirectDIAware
@required
@property (readonly) id<IPGSCKodein_diDirectDI> directDI __attribute__((swift_name("directDI")));
@property (readonly) id<IPGSCKodein_diDirectDI> dkodein __attribute__((swift_name("dkodein"))) __attribute__((unavailable("!!! THIS HAS BEEN REMOVED FROM 7.0 !!! As soon as you are using _Kodein-DI 7.x_, the old API named _Kodein_ API is broken. we highly recommend that you take some time to move from it to the new API with _DI_ named objects.")));
@end;

__attribute__((swift_name("Kodein_diDirectDIBase")))
@protocol IPGSCKodein_diDirectDIBase <IPGSCKodein_diDirectDIAware>
@required
- (id (^)(id _Nullable))FactoryArgType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("Factory(argType:type:tag:)")));
- (id (^ _Nullable)(id _Nullable))FactoryOrNullArgType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("FactoryOrNull(argType:type:tag:)")));
- (id)InstanceType:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("Instance(type:tag:)")));
- (id)InstanceArgType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag arg:(id _Nullable)arg __attribute__((swift_name("Instance(argType:type:tag:arg:)")));
- (id _Nullable)InstanceOrNullType:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("InstanceOrNull(type:tag:)")));
- (id _Nullable)InstanceOrNullArgType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag arg:(id _Nullable)arg __attribute__((swift_name("InstanceOrNull(argType:type:tag:arg:)")));
- (id<IPGSCKodein_diDirectDI>)OnContext:(id<IPGSCKodein_diDIContext>)context __attribute__((swift_name("On(context:)")));
- (id (^)(void))ProviderType:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("Provider(type:tag:)")));
- (id (^)(void))ProviderArgType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag arg:(id _Nullable (^)(void))arg __attribute__((swift_name("Provider(argType:type:tag:arg:)")));
- (id (^ _Nullable)(void))ProviderOrNullType:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag __attribute__((swift_name("ProviderOrNull(type:tag:)")));
- (id (^ _Nullable)(void))ProviderOrNullArgType:(IPGSCKodein_typeTypeToken *)argType type:(IPGSCKodein_typeTypeToken *)type tag:(id _Nullable)tag arg:(id _Nullable (^)(void))arg __attribute__((swift_name("ProviderOrNull(argType:type:tag:arg:)")));
@property (readonly) id<IPGSCKodein_diDIContainer> container __attribute__((swift_name("container")));
@property (readonly) id<IPGSCKodein_diDI> di __attribute__((swift_name("di")));
@property (readonly) id<IPGSCKodein_diDI> kodein __attribute__((swift_name("kodein"))) __attribute__((unavailable("!!! THIS HAS BEEN REMOVED FROM 7.0 !!! As soon as you are using _Kodein-DI 7.x_, the old API named _Kodein_ API is broken. we highly recommend that you take some time to move from it to the new API with _DI_ named objects.")));
@property (readonly) id<IPGSCKodein_diDI> lazy __attribute__((swift_name("lazy")));
@end;

__attribute__((swift_name("Kodein_diDirectDI")))
@protocol IPGSCKodein_diDirectDI <IPGSCKodein_diDirectDIBase>
@required
@end;

__attribute__((swift_name("Kodein_diDIContainerBuilder")))
@protocol IPGSCKodein_diDIContainerBuilder
@required
- (void)bindKey:(IPGSCKodein_diDIKey *)key binding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule overrides:(IPGSCBoolean * _Nullable)overrides __attribute__((swift_name("bind(key:binding:fromModule:overrides:)")));
- (void)extendContainer:(id<IPGSCKodein_diDIContainer>)container allowOverride:(BOOL)allowOverride copy:(NSSet<IPGSCKodein_diDIKey *> *)copy __attribute__((swift_name("extend(container:allowOverride:copy:)")));
- (void)onReadyCb:(void (^)(id<IPGSCKodein_diDirectDI>))cb __attribute__((swift_name("onReady(cb:)")));
- (void)registerContextTranslatorTranslator:(id<IPGSCKodein_diContextTranslator>)translator __attribute__((swift_name("registerContextTranslator(translator:)")));
- (id<IPGSCKodein_diDIContainerBuilder>)subBuilderAllowOverride:(BOOL)allowOverride silentOverride:(BOOL)silentOverride __attribute__((swift_name("subBuilder(allowOverride:silentOverride:)")));
@end;

__attribute__((swift_name("Kodein_diScope")))
@protocol IPGSCKodein_diScope
@required
- (IPGSCKodein_diScopeRegistry *)getRegistryContext:(id _Nullable)context __attribute__((swift_name("getRegistry(context:)")));
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface IPGSCKotlinByteIterator : IPGSCBase <IPGSCKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (IPGSCByte *)next_ __attribute__((swift_name("next_()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface IPGSCKtor_httpUrl : IPGSCBase
- (instancetype)initWithProtocol:(IPGSCKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<IPGSCKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)"))) __attribute__((objc_designated_initializer));
- (IPGSCKtor_httpURLProtocol *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (id<IPGSCKtor_httpParameters>)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSString * _Nullable)component8 __attribute__((swift_name("component8()")));
- (BOOL)component9 __attribute__((swift_name("component9()")));
- (IPGSCKtor_httpUrl *)doCopyProtocol:(IPGSCKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<IPGSCKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("doCopy(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<IPGSCKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) IPGSCKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinTriple")))
@interface IPGSCKotlinTriple : IPGSCBase
- (instancetype)initWithFirst:(id _Nullable)first second:(id _Nullable)second third:(id _Nullable)third __attribute__((swift_name("init(first:second:third:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)component1 __attribute__((swift_name("component1()")));
- (id _Nullable)component2 __attribute__((swift_name("component2()")));
- (id _Nullable)component3 __attribute__((swift_name("component3()")));
- (IPGSCKotlinTriple *)doCopyFirst:(id _Nullable)first second:(id _Nullable)second third:(id _Nullable)third __attribute__((swift_name("doCopy(first:second:third:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) id _Nullable first __attribute__((swift_name("first")));
@property (readonly) id _Nullable second __attribute__((swift_name("second")));
@property (readonly) id _Nullable third __attribute__((swift_name("third")));
@end;

__attribute__((swift_name("Kodein_diSearchSpecs")))
@interface IPGSCKodein_diSearchSpecs : IPGSCBase
- (instancetype)initWithContextType:(IPGSCKodein_typeTypeToken * _Nullable)contextType argType:(IPGSCKodein_typeTypeToken * _Nullable)argType type:(IPGSCKodein_typeTypeToken * _Nullable)type tag:(id _Nullable)tag __attribute__((swift_name("init(contextType:argType:type:tag:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property IPGSCKodein_typeTypeToken * _Nullable argType __attribute__((swift_name("argType")));
@property IPGSCKodein_typeTypeToken * _Nullable contextType __attribute__((swift_name("contextType")));
@property id _Nullable tag __attribute__((swift_name("tag")));
@property IPGSCKodein_typeTypeToken * _Nullable type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("Kodein_diDIDefining")))
@interface IPGSCKodein_diDIDefining : IPGSCBase
- (instancetype)initWithBinding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule __attribute__((swift_name("init(binding:fromModule:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<IPGSCKodein_diDIBinding> binding __attribute__((swift_name("binding")));
@property (readonly) NSString * _Nullable fromModule __attribute__((swift_name("fromModule")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIDefinition")))
@interface IPGSCKodein_diDIDefinition : IPGSCKodein_diDIDefining
- (instancetype)initWithBinding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule tree:(id<IPGSCKodein_diDITree>)tree __attribute__((swift_name("init(binding:fromModule:tree:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithBinding:(id<IPGSCKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule __attribute__((swift_name("init(binding:fromModule:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) id<IPGSCKodein_diDITree> tree __attribute__((swift_name("tree")));
@end;

__attribute__((swift_name("Kodein_diExternalSource")))
@protocol IPGSCKodein_diExternalSource
@required
- (id (^ _Nullable)(id _Nullable))getFactoryDi:(id<IPGSCKodein_diBindingDI>)di key:(IPGSCKodein_diDIKey *)key __attribute__((swift_name("getFactory(di:key:)")));
@end;

__attribute__((swift_name("Kodein_diBinding")))
@protocol IPGSCKodein_diBinding
@required
- (id (^)(id _Nullable))getFactoryDi:(id<IPGSCKodein_diBindingDI>)di key_:(IPGSCKodein_diDIKey *)key __attribute__((swift_name("getFactory(di:key_:)")));
@end;

__attribute__((swift_name("Kodein_diDIBinding")))
@protocol IPGSCKodein_diDIBinding <IPGSCKodein_diBinding>
@required
- (NSString *)factoryFullName __attribute__((swift_name("factoryFullName()")));
- (NSString *)factoryName __attribute__((swift_name("factoryName()")));
@property (readonly) IPGSCKodein_typeTypeToken *argType __attribute__((swift_name("argType")));
@property (readonly) IPGSCKodein_typeTypeToken *contextType __attribute__((swift_name("contextType")));
@property (readonly) id<IPGSCKodein_diDIBindingCopier> _Nullable copier __attribute__((swift_name("copier")));
@property (readonly) IPGSCKodein_typeTypeToken *createdType __attribute__((swift_name("createdType")));
@property (readonly, getter=description_) NSString *description __attribute__((swift_name("description")));
@property (readonly) NSString *fullDescription __attribute__((swift_name("fullDescription")));
@property (readonly) id<IPGSCKodein_diScope> _Nullable scope __attribute__((swift_name("scope")));
@property (readonly) BOOL supportSubTypes __attribute__((swift_name("supportSubTypes")));
@end;

__attribute__((swift_name("Kodein_diScopeCloseable")))
@protocol IPGSCKodein_diScopeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("Kodein_diScopeRegistry")))
@interface IPGSCKodein_diScopeRegistry : IPGSCBase <IPGSCKodein_diScopeCloseable>
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (id)getOrCreateKey:(id)key sync:(BOOL)sync creator:(IPGSCKodein_diReference *(^)(void))creator __attribute__((swift_name("getOrCreate(key:sync:creator:)")));
- (id _Nullable (^ _Nullable)(void))getOrNullKey_:(id)key __attribute__((swift_name("getOrNull(key_:)")));
- (void)removeKey_:(id)key __attribute__((swift_name("remove(key_:)")));
- (id)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface IPGSCKtor_httpURLProtocol : IPGSCBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (IPGSCKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Kodein_diWithContext")))
@protocol IPGSCKodein_diWithContext
@required
@property (readonly) id context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kodein_diSimpleBindingDI")))
@protocol IPGSCKodein_diSimpleBindingDI <IPGSCKodein_diDirectDI, IPGSCKodein_diWithContext>
@required
- (id (^)(id _Nullable))overriddenFactory __attribute__((swift_name("overriddenFactory()")));
- (id (^ _Nullable)(id _Nullable))overriddenFactoryOrNull __attribute__((swift_name("overriddenFactoryOrNull()")));
@end;

__attribute__((swift_name("Kodein_diBindingDI")))
@protocol IPGSCKodein_diBindingDI <IPGSCKodein_diSimpleBindingDI>
@required
@end;

__attribute__((swift_name("Kodein_diDIBindingCopier")))
@protocol IPGSCKodein_diDIBindingCopier
@required
- (id<IPGSCKodein_diDIBinding>)doCopyBuilder:(id<IPGSCKodein_diDIContainerBuilder>)builder __attribute__((swift_name("doCopy(builder:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diReference")))
@interface IPGSCKodein_diReference : IPGSCBase
- (instancetype)initWithCurrent:(id)current next:(id _Nullable (^)(void))next __attribute__((swift_name("init(current:next:)"))) __attribute__((objc_designated_initializer));
- (id)component1 __attribute__((swift_name("component1()")));
- (id _Nullable (^)(void))component2 __attribute__((swift_name("component2()")));
- (IPGSCKodein_diReference *)doCopyCurrent:(id)current next:(id _Nullable (^)(void))next __attribute__((swift_name("doCopy(current:next:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id current __attribute__((swift_name("current")));
@property (readonly) id _Nullable (^next)(void) __attribute__((swift_name("next")));
@end;

#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
