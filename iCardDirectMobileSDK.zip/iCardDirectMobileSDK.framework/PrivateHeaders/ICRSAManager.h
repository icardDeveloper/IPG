//
//  ICRSAManager.h
//  ICCheckout
//
//  Created by Valio Cholakov on 1/31/17.
//  Copyright © 2017 Intercard Finance AD. All rights reserved.
//

#import "ICBaseManager.h"

@interface ICRSAManager : ICBaseManager

- (NSString *)signData:(NSData *)data;
- (NSString *)signString:(NSString *)string;
- (NSString *)signStringWithSha:(NSString *) dataToSign;
- (BOOL)signatureIsValid:(NSString *)signedString plainString:(NSString *)plainString;
- (NSString *)encryptedString:(NSString *)string;
- (NSString *)decryptedString:(NSString *)string;

- (SecKeyRef)publicKeyFromCertificate:(NSData *)certificateData;
- (SecKeyRef)privateKeyFromFile:(NSData *)fileData;
- (NSString *)prepareStringForValidation:(NSString *) string;
-(void)testEncode:(NSString *)str ;

@property (nonatomic, readonly) SecKeyRef publicKey;
@property (nonatomic, readonly) SecKeyRef privateKey;
@property (nonatomic, strong) NSString *_publicKeyName;
@property (nonatomic, strong) NSString *_privateKeyName;
@property (nonatomic) BOOL isSandbox;

@end
